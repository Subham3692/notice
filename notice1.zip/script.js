let scale = 1;
let posX = 0, posY = 0;
let startX, startY;
let isDragging = false;

function openModal(src) {
    const modal = document.getElementById("imageModal");
    const img = document.getElementById("modalImg");

    modal.style.display = "flex";
    img.src = src;

    // reset
    scale = 1;
    posX = 0;
    posY = 0;

    updateTransform();
}

function closeModal() {
    document.getElementById("imageModal").style.display = "none";
}

function updateTransform() {
    const img = document.getElementById("modalImg");
    img.style.transform = `translate(${posX}px, ${posY}px) scale(${scale})`;
}

// Zoom with mouse wheel
document.addEventListener("wheel", function(e) {
    const modal = document.getElementById("imageModal");
    if (modal.style.display !== "flex") return;

    e.preventDefault();

    if (e.deltaY < 0) {
        scale += 0.1; // zoom in
    } else {
        scale -= 0.1; // zoom out
    }

    scale = Math.max(1, Math.min(scale, 5)); // limit
    updateTransform();
}, { passive: false });

// Drag start
document.addEventListener("mousedown", function(e) {
    const modal = document.getElementById("imageModal");
    if (modal.style.display !== "flex") return;

    isDragging = true;
    startX = e.clientX - posX;
    startY = e.clientY - posY;
});

// Drag move
document.addEventListener("mousemove", function(e) {
    if (!isDragging) return;

    posX = e.clientX - startX;
    posY = e.clientY - startY;
    updateTransform();
});

// Drag end
document.addEventListener("mouseup", function() {
    isDragging = false;
});

// Double click zoom
document.getElementById("modalImg").addEventListener("dblclick", function(e) {
    e.stopPropagation();

    scale = scale === 1 ? 2 : 1;
    updateTransform();
});