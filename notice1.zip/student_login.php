<?php
session_start();
require_once 'admin/database.php';

$error = '';

// For debugging - you can remove this after testing
$debug_info = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rollno = trim($_POST['rollno']);
    $password = trim($_POST['password']);
    
    // First get the student by roll number
    $stmt = $pdo->prepare("SELECT * FROM students WHERE rollno = ?");
    $stmt->execute([$rollno]);
    $student = $stmt->fetch();
    
    // Debug information (remove in production)
    if($student) {
        $debug_info = "Student found. Password in DB: " . substr($student['password'], 0, 20) . "...";
        $debug_info .= "<br>Using password_verify: " . (password_verify($password, $student['password']) ? "TRUE" : "FALSE");
    } else {
        $debug_info = "No student found with roll number: " . htmlspecialchars($rollno);
    }
    
    // Verify the hashed password
    if($student && password_verify($password, $student['password'])) {
        $_SESSION['student_logged_in'] = true;
        $_SESSION['student_id'] = $student['id'];
        $_SESSION['student_name'] = $student['name'];
        $_SESSION['student_rollno'] = $student['rollno'];
        $_SESSION['student_department'] = $student['department'];
        $_SESSION['student_semester'] = $student['semester'];
        $_SESSION['student_phone'] = $student['phone'];
        header('Location: index.php');
        exit();
    } else {
        $error = "Invalid Roll Number or Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Student Login - College Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Background Bubbles */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, rgba(255,255,255,0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255,255,255,0.08) 0%, transparent 50%);
            pointer-events: none;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* Login Container */
        .login-container {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 32px;
            padding: 40px 32px;
            width: 100%;
            max-width: 460px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            animation: fadeInUp 0.6s ease-out;
            position: relative;
            z-index: 1;
            transition: all 0.3s ease;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 24px;
                border-radius: 28px;
            }
        }

        /* Login Header */
        .login-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .login-header .logo-icon {
            font-size: 56px;
            margin-bottom: 16px;
            display: inline-block;
            animation: float 3s ease-in-out infinite;
        }

        .login-header h1 {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        @media (max-width: 480px) {
            .login-header h1 {
                font-size: 24px;
            }
        }

        .login-header p {
            color: #6c757d;
            font-size: 14px;
        }

        /* Error Message */
        .error-message {
            background: linear-gradient(135deg, #f8d7da 0%, #fce4e6 100%);
            color: #c0392b;
            padding: 14px 18px;
            border-radius: 16px;
            margin-bottom: 24px;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border-left: 4px solid #e74c3c;
            animation: shake 0.4s ease;
        }

        .error-message i {
            font-size: 18px;
        }

        /* Form Styles */
        .login-form .form-group {
            margin-bottom: 24px;
        }

        .login-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1a1a2e;
            font-size: 14px;
        }

        .login-form label i {
            margin-right: 8px;
            color: #667eea;
        }

        .input-wrapper {
            position: relative;
        }

        .login-form input {
            width: 100%;
            padding: 14px 16px 14px 48px;
            border: 2px solid #e9ecef;
            border-radius: 16px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .login-form input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15);
        }

        .input-wrapper i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #adb5bd;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .login-form input:focus + i {
            color: #667eea;
        }

        /* Password wrapper for toggle button */
        .password-wrapper {
            position: relative;
        }
        
        .password-wrapper input {
            padding-right: 48px;
        }
        
        .toggle-password {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #adb5bd;
            font-size: 18px;
            transition: color 0.3s ease;
            z-index: 2;
        }
        
        .toggle-password:hover {
            color: #667eea;
        }

        /* Button Styles */
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 40px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 8px;
            position: relative;
            overflow: hidden;
        }

        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s ease;
        }

        .btn-login:hover::before {
            left: 100%;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(102, 126, 234, 0.4);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        /* Demo Credentials */
        .demo-credentials {
            margin-top: 32px;
            padding: 20px;
            background: linear-gradient(135deg, #f8f9fa 0%, #f1f3f5 100%);
            border-radius: 20px;
            transition: all 0.3s ease;
        }

        .demo-credentials:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .demo-credentials h4 {
            margin-bottom: 12px;
            color: #1a1a2e;
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .demo-credentials h4 i {
            color: #f39c12;
        }

        .demo-credentials p {
            margin: 6px 0;
            color: #6c757d;
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .demo-credentials p i {
            width: 20px;
            color: #667eea;
        }

        .demo-credentials small {
            display: block;
            margin-top: 12px;
            font-size: 11px;
            color: #adb5bd;
            text-align: center;
        }

        /* Footer Links */
        .login-footer {
            text-align: center;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        .login-footer a {
            color: #667eea;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .login-footer a:hover {
            color: #764ba2;
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #6c757d;
        }
        
        .register-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .register-link a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }
            
            .login-container {
                max-width: 100%;
            }
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 28px 20px;
            }
            
            .login-header .logo-icon {
                font-size: 48px;
            }
            
            .login-form input {
                padding: 12px 16px 12px 44px;
                font-size: 14px;
            }
            
            .input-wrapper i {
                font-size: 16px;
                left: 14px;
            }
            
            .btn-login {
                padding: 12px;
                font-size: 15px;
            }
        }

        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            .login-container {
                background: rgba(30, 30, 40, 0.98);
            }
            
            .login-header p,
            .demo-credentials p,
            .demo-credentials small {
                color: #a0a0b0;
            }
            
            .demo-credentials {
                background: rgba(40, 40, 50, 0.8);
            }
            
            .demo-credentials h4 {
                color: white;
            }
            
            .login-form input {
                background: #2a2a35;
                border-color: #3a3a45;
                color: #003eff;
            }
            
            .login-form label {
                color: #e0e0e0;
            }
            
            .register-link {
                color: #a0a0b0;
            }
        }

        /* Loading state for button */
        .btn-login.loading {
            pointer-events: none;
            opacity: 0.7;
        }

        .btn-login.loading i {
            animation: pulse 1s ease infinite;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo-icon">
                🎓
            </div>
            <h1>Student Login</h1>
            <p>Access your notice board and complaints</p>
        </div>
        
        <?php if($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="" class="login-form" id="loginForm">
            <div class="form-group">
                <label>
                    <i class="fas fa-id-card"></i> Roll Number
                </label>
                <div class="input-wrapper">
                    <input type="text" name="rollno" required placeholder="Enter your roll number" autocomplete="off" value="<?php echo isset($_POST['rollno']) ? htmlspecialchars($_POST['rollno']) : ''; ?>">
                    <i class="fas fa-user-graduate"></i>
                </div>
            </div>
            
            <div class="form-group">
                <label>
                    <i class="fas fa-lock"></i> Password
                </label>
                <div class="password-wrapper">
                    <input type="password" name="password" required placeholder="Enter your password" id="password">
                    <i class="fas fa-eye toggle-password" id="togglePassword"></i>
                </div>
            </div>
            
            <button type="submit" class="btn-login" id="loginBtn">
                <i class="fas fa-sign-in-alt"></i>
                Login
            </button>
        </form>
        
        <div class="register-link">
            New User? <a href="student_register.php">Register here</a>
        </div>
        
    </div>

    <script>
        // Add loading animation on form submit
        const loginForm = document.getElementById('loginForm');
        const loginBtn = document.getElementById('loginBtn');
        
        if (loginForm) {
            loginForm.addEventListener('submit', function() {
                loginBtn.classList.add('loading');
                loginBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Logging in...';
            });
        }
        
        // Password visibility toggle
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function() {
                // Toggle the type attribute
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                // Toggle the eye icon
                this.classList.toggle('fa-eye');
                this.classList.toggle('fa-eye-slash');
            });
        }
    </script>
</body>
</html>