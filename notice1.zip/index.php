<?php
session_start();
require_once 'admin/database.php';

if(!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: student_login.php');
    exit();
}

$student_name = $_SESSION['student_name'];
$student_rollno = $_SESSION['student_rollno'];
$student_department = $_SESSION['student_department'];
$student_semester = $_SESSION['student_semester'];

// Debug - Check what values are stored in session
// Uncomment these lines to see what values are actually in session
// echo "<!-- Department: " . $student_department . " -->";
// echo "<!-- Semester: " . $student_semester . " -->";

// Fetch banners
$banners = $pdo->query("SELECT * FROM banners ORDER BY id DESC")->fetchAll();

// Count notices for badges - MODIFIED QUERIES
// Class Notices - Show ALL class notices if no match found
$classNoticeCount = $pdo->prepare("SELECT COUNT(*) FROM class_notices WHERE semester = ? AND department = ?");
$classNoticeCount->execute([$student_semester, $student_department]);
$classNoticeCount = $classNoticeCount->fetchColumn();

// If no class notices found for specific department/semester, show all class notices
if($classNoticeCount == 0) {
    $classNoticeCountAll = $pdo->query("SELECT COUNT(*) FROM class_notices")->fetchColumn();
    if($classNoticeCountAll > 0) {
        $classNoticeCount = $classNoticeCountAll;
    }
}

// Department Notices
$deptNoticeCount = $pdo->prepare("SELECT COUNT(*) FROM department_notices WHERE department = ?");
$deptNoticeCount->execute([$student_department]);
$deptNoticeCount = $deptNoticeCount->fetchColumn();

// If no department notices found, show all department notices
if($deptNoticeCount == 0) {
    $deptNoticeCountAll = $pdo->query("SELECT COUNT(*) FROM department_notices")->fetchColumn();
    if($deptNoticeCountAll > 0) {
        $deptNoticeCount = $deptNoticeCountAll;
    }
}

// Teacher Notices
$teacherNoticeCount = $pdo->prepare("SELECT COUNT(*) FROM teacher_notices WHERE department = ? AND semester = ?");
$teacherNoticeCount->execute([$student_department, $student_semester]);
$teacherNoticeCount = $teacherNoticeCount->fetchColumn();

// If no teacher notices found, show all teacher notices
if($teacherNoticeCount == 0) {
    $teacherNoticeCountAll = $pdo->query("SELECT COUNT(*) FROM teacher_notices")->fetchColumn();
    if($teacherNoticeCountAll > 0) {
        $teacherNoticeCount = $teacherNoticeCountAll;
    }
}

// College Notices - Show all
$collegeNoticeCount = $pdo->query("SELECT COUNT(*) FROM college_notices")->fetchColumn();

// Events - Show all upcoming events (not just future dates)
$eventCount = $pdo->query("SELECT COUNT(*) FROM events WHERE event_date >= CURDATE()")->fetchColumn();
// If no upcoming events, show total events
if($eventCount == 0) {
    $eventCountAll = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
    if($eventCountAll > 0) {
        $eventCount = $eventCountAll;
    }
}

// Student Complaints
$complaintCount = $pdo->prepare("SELECT COUNT(*) FROM student_complaints WHERE student_rollno = ?");
$complaintCount->execute([$student_rollno]);
$complaintCount = $complaintCount->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Student Dashboard - College Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
/* ================= CHATBOT BUTTON ================= */
.circle-btn {
position: fixed;
bottom: 90px; /* Above mobile navbar */
right: 15px;
background: linear-gradient(135deg, #6c63ff, #4a47d5);
color: white;
padding: 12px 18px;
border-radius: 50px;
cursor: pointer;
font-size: 14px;
font-weight: 600;
box-shadow: 0 4px 12px rgba(0,0,0,0.25);
z-index: 9999;
transition: 0.3s ease;
}

.circle-btn:hover {
transform: scale(1.05);
background: linear-gradient(135deg, #5a54e8, #3c38c9);
}

/* ================= CHAT WINDOW ================= */
.chat-window {
position: fixed;
bottom: 150px;
right: 15px;
width: 320px;
max-width: 95%;
background: #ffffff;
border-radius: 12px;
display: none;
flex-direction: column;
overflow: hidden;
box-shadow: 0 8px 25px rgba(0,0,0,0.2);
z-index: 9999;
animation: fadeIn 0.3s ease;
}

.chat-window.show {
display: flex;
}

/* ================= HEADER ================= */
.chat-header {
background: linear-gradient(135deg, #6c63ff, #4a47d5);
color: white;
padding: 12px;
font-weight: 600;
display: flex;
justify-content: space-between;
align-items: center;
}

.chat-header button {
background: transparent;
border: none;
color: white;
font-size: 16px;
cursor: pointer;
}

/* ================= MESSAGES ================= */
.chat-messages {
height: 260px;
overflow-y: auto;
padding: 10px;
background: #f7f7fb;
}

/* Bot Message */
.bot {
background: #e4e6ff;
color: #333;
padding: 8px 10px;
margin: 6px 0;
border-radius: 10px;
max-width: 80%;
font-size: 13px;
}

/* User Message */
.user {
background: #6c63ff;
color: white;
padding: 8px 10px;
margin: 6px 0;
border-radius: 10px;
max-width: 80%;
margin-left: auto;
text-align: right;
font-size: 13px;
}

/* ================= INPUT AREA ================= */
.chat-input {
display: flex;
border-top: 1px solid #ddd;
background: white;
}

.chat-input input {
flex: 1;
padding: 10px;
border: none;
outline: none;
font-size: 13px;
}

.chat-input button {
padding: 10px 14px;
border: none;
background: #6c63ff;
color: white;
cursor: pointer;
transition: 0.3s;
}

.chat-input button:hover {
background: #4a47d5;
}

/* ================= SCROLLBAR ================= */
.chat-messages::-webkit-scrollbar {
width: 5px;
}

.chat-messages::-webkit-scrollbar-thumb {
background: #ccc;
border-radius: 10px;
}

/* ================= ANIMATION ================= */
@keyframes fadeIn {
from { opacity: 0; transform: translateY(20px); }
to { opacity: 1; transform: translateY(0); }
}

/* ================= MOBILE RESPONSIVE ================= */
@media (max-width: 768px) {

```
.circle-btn {
    bottom: 80px;
    right: 10px;
    padding: 10px 14px;
    font-size: 13px;
}

.chat-window {
    bottom: 140px;
    right: 5%;
    width: 90%;
}

.chat-messages {
    height: 220px;
}
```

}

    </style>
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="logo-area">
            <h2>🎓 Online Notice</h2>
        </div>
        <div class="student-info">
            <div class="student-details">
                <div class="student-name"><?php echo htmlspecialchars($student_name); ?></div>
                <div class="student-roll"><?php echo htmlspecialchars($student_rollno); ?></div>
            </div>
            <a href="student_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
    
    <!-- Banner Slider -->
    <div class="banner-slider">
        <button class="prev" onclick="changeSlide(-1)">❮</button>
        <div class="slider-container" id="slider">
            <?php if(empty($banners)): ?>
                <div class="slide">
                    <img src="https://via.placeholder.com/1200x400?text=No+Banners+Available" alt="No banner">
                    <div class="slide-content"><h3>Welcome to College Portal</h3></div>
                </div>
            <?php else: ?>
                <?php foreach($banners as $banner): ?>
                    <div class="slide">
                        <?php if($banner['link_url']): ?>
                            <a href="<?php echo htmlspecialchars($banner['link_url']); ?>" target="_blank">
                                <img src="admin/<?php echo $banner['image_path']; ?>" alt="<?php echo htmlspecialchars($banner['title']); ?>">
                            </a>
                        <?php else: ?>
                            <img src="admin/<?php echo $banner['image_path']; ?>" alt="<?php echo htmlspecialchars($banner['title']); ?>">
                        <?php endif; ?>
                        <div class="slide-content">
                            <h3><?php echo htmlspecialchars($banner['title']); ?></h3>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <button class="next" onclick="changeSlide(1)">❯</button>
        <div class="dots" id="dots"></div>
    </div>
    
    <!-- Cards Section -->
    <div class="cards-section">
        <h2 class="section-title">📋 Notice & Services</h2>
        <div class="cards-grid">
            <a href="class_notices.php" class="feature-card card-class">
                <div class="card-icon">📚</div>
                <h3>Class Notices</h3>
                <p>View notices for your semester and department</p>
                <span class="badge"><?php echo $classNoticeCount; ?> New</span>
            </a>
            
            <a href="department_notices.php" class="feature-card card-dept">
                <div class="card-icon">🏛️</div>
                <h3>Department Notice</h3>
                <p>Department-specific announcements</p>
                <span class="badge"><?php echo $deptNoticeCount; ?> New</span>
            </a>
            
            <a href="teacher_notices.php" class="feature-card card-teacher">
                <div class="card-icon">👩‍🏫</div>
                <h3>Teacher Notices</h3>
                <p>Notices from your teachers</p>
                <span class="badge"><?php echo $teacherNoticeCount; ?> New</span>
            </a>
            
            <a href="college_notices.php" class="feature-card card-college">
                <div class="card-icon">🏫</div>
                <h3>College Notice</h3>
                <p>Official college announcements</p>
                <span class="badge"><?php echo $collegeNoticeCount; ?> New</span>
            </a>
            
            <a href="events.php" class="feature-card card-event">
                <div class="card-icon">🎉</div>
                <h3>Events Notice</h3>
                <p>Upcoming events and workshops</p>
                <span class="badge"><?php echo $eventCount; ?> Upcoming</span>
            </a>
            
            <a href="student_complaint.php" class="feature-card card-complaint">
                <div class="card-icon">📝</div>
                <h3>Student Complain</h3>
                <p>Submit or track your complaints</p>
                <span class="badge"><?php echo $complaintCount; ?> Submitted</span>
            </a>
            <br>
            <br>
        </div>
    </div>
    <div class="circle-btn" onclick="toggleChat()">Hii</div>

<div class="chat-window" id="chatbot">
    <div class="chat-header">
        Notice System Help
        <button onclick="toggleChat()">X</button>
    </div>

    <div class="chat-messages" id="chat-messages">
        <div class="bot">👋 Hello! Welcome to College Notice Board System. How can I help you?</div>
    </div>

    <div class="chat-input">
        <input type="text" id="user-input" placeholder="Ask about notices, events, complaints...">
        <button onclick="sendMessage()">Send</button>
    </div>
</div>

    <!-- Bottom Navigation (Mobile) -->
    <div class="bottom-nav">
        <a href="teacher_notices.php" class="nav-item">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teacher</span>
        </a>
        <a href="class_notices.php" class="nav-item">
            <i class="fas fa-book"></i>
            <span>Class</span>
        </a>
        <a href="college_notices.php" class="nav-item">
            <i class="fas fa-university"></i>
            <span>College</span>
        </a>
        <a href="events.php" class="nav-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Events</span>
        </a>
        <a href="student_complaint.php" class="nav-item">
            <i class="fas fa-file-alt"></i>
            <span>Complaint</span>
        </a>
    </div>
    
    <script>
        let slideIndex = 0;
        const slides = document.querySelectorAll('.slide');
        const dotsContainer = document.getElementById('dots');
        
        if(slides.length > 0) {
            for(let i = 0; i < slides.length; i++) {
                const dot = document.createElement('div');
                dot.classList.add('dot');
                dot.onclick = () => currentSlide(i);
                dotsContainer.appendChild(dot);
            }
            showSlide();
            setInterval(() => changeSlide(1), 5000);
        }
        
        function changeSlide(n) {
            slideIndex += n;
            if(slideIndex >= slides.length) slideIndex = 0;
            if(slideIndex < 0) slideIndex = slides.length - 1;
            showSlide();
        }
        
        function currentSlide(n) {
            slideIndex = n;
            showSlide();
        }
        
        function showSlide() {
            const slider = document.getElementById('slider');
            if(slider) {
                slider.style.transform = `translateX(-${slideIndex * 100}%)`;
                const dots = document.querySelectorAll('.dot');
                dots.forEach((dot, i) => {
                    dot.classList.toggle('active', i === slideIndex);
                });
            }
        }
    </script>

<script>

function toggleChat() {
    document.getElementById("chatbot").classList.toggle("show");
}

function sendMessage() {
    var input = document.getElementById("user-input");
    var message = input.value.trim();
    if (!message) return;

    var chatBox = document.getElementById("chat-messages");

    chatBox.innerHTML += '<div class="user">' + message + '</div>';
    chatBox.scrollTop = chatBox.scrollHeight;

    input.value = "";

    setTimeout(function () {
        chatBox.innerHTML += '<div class="bot">' + getBotReply(message) + '</div>';
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 500);
}

function getBotReply(message) {
    var m = message.toLowerCase();

    // Greeting
    if (m.includes("hi") || m.includes("hello") || m.includes("hey") || m.includes("greetings") || m.includes("welcome") || m.includes("good morning") || m.includes("good afternoon") || m.includes("good evening") || m.includes("how are you") || m.includes("how are you doing") || m.includes("Namaskar") || m.includes("whats up"))
        return "Hello 👋! Welcome to College Notice Board System.";

    // Notices
    if (m.includes("notice") || m.includes("notices") || m.includes("announcement") || m.includes("announcements") || m.includes("news") || m.includes("update") || m.includes("updates") || m.includes("information") || m.includes("inform") || m.includes("inform me") || m.includes("what's new") || m.includes("what is new") || m.includes("any news") || m.includes("any update") || m.includes("any updates"))
        return "📢 You can check Class, Department, Teacher, and College notices from dashboard.";

    if (m.includes("class") || m.includes("semester") || m.includes("course") || m.includes("subject"))
        return "📚 Class notices are based on your semester and department.";

    if (m.includes("department"))
        return "🏛️ Department notices are posted by your department.";

    if (m.includes("teacher"))
        return "👩‍🏫 Teacher notices are shared by teachers for students.";

    if (m.includes("college"))
        return "🏫 College notices include official announcements.";

    // Events
    if (m.includes("event"))
        return "🎉 You can view upcoming events and workshops in the Events section.";

    // Complaint
    if (m.includes("complaint"))
        return "📝 You can submit complaints and track their status (Pending, Resolved).";

    if (m.includes("status"))
        return "📊 Complaint status can be checked in the complaint section.";

    // Login
    if (m.includes("login"))
        return "🔐 Login using your Roll Number and Password.";

    if (m.includes("who are you") || m.includes("about you"))
    return "🤖 I am a virtual assistant for the College Notice Board Management System. I help students find notices, events, and complaint information quickly.";

    if (m.includes("who built you") || m.includes("who build you") || m.includes("who developed you") || m.includes("who made you") || m.includes("who created you") || m.includes("who are your developers") || m.includes("who is your developer") || m.includes("who is your creator") || m.includes("who make you"))
    return "👨‍💻 I was developed as part of the College Notice Board Management System project by BCA 6th Semester students of Mangaldai College.";

    // Admin
    if (m.includes("admin"))
        return "⚙️ Admin can manage students, teachers, notices, events, and complaints.";

    // Default
    return "❗ Sorry, I didn’t understand. Try asking about notices, events, or complaints.";
}

</script>
</body>
</html>