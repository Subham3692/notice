<?php
session_start();
require_once 'admin/database.php';

if(!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: student_login.php');
    exit();
}

$student_name = $_SESSION['student_name'];
$student_rollno = $_SESSION['student_rollno'];
$student_department = $_SESSION['student_department'];
$student_semester = $_SESSION['student_semester'];

$events = $pdo->query("SELECT * FROM events ORDER BY event_date ASC, id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Events - Student Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
        <script src="script.js"></script>
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.95);
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

/* Image */
.modal-content {
    max-width: 95%;
    max-height: 90%;
    width: auto;
    height: auto;
    object-fit: contain;

    cursor: grab;
    transition: transform 0.1s ease;
    user-select: none;
}


/* Close */
.close {
    position: absolute;
    top: 20px;
    right: 30px;
    font-size: 35px;
    color: #fff;
    cursor: pointer;
}
.logo a {
    text-decoration: none;
    color: inherit;
}
</style>

</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="logo-area">
            <a href="index.php" style="text-decoration: none; color: inherit;">
            <h2>🎓 Online Notice</h2>
            </a>
        </div>
        <div class="student-info">
            <div class="student-details">
                <div class="student-name"><?php echo htmlspecialchars($student_name); ?></div>
                <div class="student-roll"><?php echo htmlspecialchars($student_rollno); ?></div>
            </div>
            <a href="index.php" class="back-btn">Back</a>
        </div>
    </div>
    
    <!-- Page Header -->
    <div class="page-header">
                <br>
        <h1>ðŸŽ‰ Upcoming Events</h1>
        <p>Workshops, seminars, and celebrations</p>
        <div class="info-badge">
            <i class="fas fa-calendar-check"></i> Don't miss out on these events
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <?php if(empty($events)): ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <h3>No Events Found</h3>
                    <p>No upcoming events are scheduled at this time.</p>
                </div>
            <?php else: ?>
                <?php foreach($events as $event): ?>
                    <div class="event-card">
                        <div class="event-title"><?php echo htmlspecialchars($event['title']); ?></div>
                        <div class="event-date"><i class="far fa-calendar-alt"></i> <?php echo date('d F Y', strtotime($event['event_date'])); ?></div>
                        <div class="event-text"><?php echo nl2br(htmlspecialchars($event['event_text'])); ?></div>
                        <?php if($event['link_url']): ?>
                            <div class="event-link">
                                <a href="<?php echo htmlspecialchars($event['link_url']); ?>" target="_blank">
                                    <i class="fas fa-external-link-alt"></i> Notice Link â†’
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php if($event['image_path'] && file_exists('admin/' . $event['image_path'])): ?>
                            <div class="event-image">
                                <img src="admin/<?php echo $event['image_path']; ?>" alt="Event Image" onclick="openModal(this.src)">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Bottom Navigation (Mobile) -->
    <div class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="class_notices.php" class="nav-item">
            <i class="fas fa-book"></i>
            <span>Class</span>
        </a>
        <a href="college_notices.php" class="nav-item">
            <i class="fas fa-university"></i>
            <span>College</span>
        </a>
        <a href="teacher_notices.php" class="nav-item active">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teacher</span>
        </a>
        <a href="student_complaint.php" class="nav-item">
            <i class="fas fa-file-alt"></i>
            <span>Complaint</span>
        </a>
    </div>

    <!-- Image Modal -->
<div id="imageModal" class="modal" onclick="closeModal()">
    <span class="close">&times;</span>
    <img id="modalImg" class="modal-content">
</div>

</body>
</html>