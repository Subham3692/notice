<?php
// ==================== login.php (Only Teacher Login - No Admin) ====================
session_start();
require_once 'database.php';

// Check if already logged in as teacher
if(isset($_SESSION['teacher_logged_in']) && $_SESSION['teacher_logged_in'] === true) {
    header('Location: index.php');
    exit();
}

$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    // Teacher Login - Check from database (plain text - NO HASHING)
    // Teacher can login using email or name
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE (email = ? OR name = ?) AND password = ?");
    $stmt->execute([$username, $username, $password]);
    $teacher = $stmt->fetch();
    
    if($teacher) {
        $_SESSION['teacher_logged_in'] = true;
        $_SESSION['teacher_id'] = $teacher['id'];
        $_SESSION['teacher_name'] = $teacher['name'];
        $_SESSION['teacher_email'] = $teacher['email'];
        $_SESSION['teacher_department'] = $teacher['department'];
        $_SESSION['user_type'] = 'teacher';
        $_SESSION['user_id'] = $teacher['id'];
        $_SESSION['user_name'] = $teacher['name'];
        header('Location: index.php');
        exit();
    } else {
        $error = 'Invalid teacher email/name or password!';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login - College Portal</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .login-wrapper {
            width: 100%;
            max-width: 450px;
            padding: 20px;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            padding: 40px 32px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .login-header {
            text-align: center;
            margin-bottom: 32px;
        }
        .login-header h2 {
            font-size: 28px;
            color: #1a1a2e;
            margin-bottom: 8px;
        }
        .login-header p {
            color: #666;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
        }
        .btn-login {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .login-footer {
            text-align: center;
            margin-top: 24px;
            color: #888;
            font-size: 12px;
        }
        .info-note {
            background: #e8f4f8;
            padding: 12px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 12px;
            color: #0066cc;
        }
        .info-note strong {
            display: block;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">
            <div class="login-header">
                <h2>Teacher Portal Login</h2>
                <p>Enter your credentials to access index</p>
            </div>
            
            <?php if($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>Email or Name</label>
                    <input type="text" name="username" required placeholder="Enter your email or name">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required placeholder="Enter your password">
                </div>
                <button type="submit" class="btn-login">Login as Teacher</button>
            </form>
                    </div>
    </div>
</body>
</html>