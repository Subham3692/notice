<?php
// ==================== Updated student.php with password field (plain text - no hashing) ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Handle Add/Edit/Delete
$message = '';
$error = '';
$editStudent = null;

// Delete
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Student deleted successfully!";
    } else {
        $error = "Failed to delete student.";
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $editStudent = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $rollno = trim($_POST['rollno']);
    $phone = trim($_POST['phone']);
    $semester = (int)$_POST['semester'];
    $department = trim($_POST['department']);
    $password = trim($_POST['password']); // Plain text password - NO HASHING
    
    if(isset($_POST['student_id']) && !empty($_POST['student_id'])) {
        // Update - only update password if provided
        $id = $_POST['student_id'];
        if(!empty($password)) {
            $stmt = $pdo->prepare("UPDATE students SET name=?, rollno=?, phone=?, semester=?, department=?, password=? WHERE id=?");
            $stmt->execute([$name, $rollno, $phone, $semester, $department, $password, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE students SET name=?, rollno=?, phone=?, semester=?, department=? WHERE id=?");
            $stmt->execute([$name, $rollno, $phone, $semester, $department, $id]);
        }
        $message = "Student updated successfully!";
        $editStudent = null;
    } else {
        // Insert - password is required for new students
        if(empty($password)) {
            $error = "Password is required for new students!";
        } else {
            $stmt = $pdo->prepare("INSERT INTO students (name, rollno, phone, semester, department, password) VALUES (?, ?, ?, ?, ?, ?)");
            if($stmt->execute([$name, $rollno, $phone, $semester, $department, $password])) {
                $message = "Student added successfully!";
            } else {
                $error = "Failed to add student. Roll number might already exist.";
            }
        }
    }
}

// Fetch all students
$students = $pdo->query("SELECT id, name, rollno, phone, semester, department, created_at FROM students ORDER BY id DESC")->fetchAll();

// Fetch departments from departments table
$departments = $pdo->query("SELECT id, name, code FROM departments ORDER BY name")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>👨‍🎓 Student Management</h1>
        <p>Manage student records with login credentials</p>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editStudent ? '✏️ Edit Student' : '➕ Add New Student'; ?></h2>
        <form method="POST" action="" class="admin-form">
            <?php if($editStudent): ?>
                <input type="hidden" name="student_id" value="<?php echo $editStudent['id']; ?>">
            <?php endif; ?>
            <div class="form-row">
                <div class="form-group">
                    <label>Student Name *</label>
                    <input type="text" name="name" required value="<?php echo $editStudent ? htmlspecialchars($editStudent['name']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Roll Number *</label>
                    <input type="text" name="rollno" required value="<?php echo $editStudent ? htmlspecialchars($editStudent['rollno']) : ''; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="phone" required value="<?php echo $editStudent ? htmlspecialchars($editStudent['phone']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Semester *</label>
                    <select name="semester" required>
                        <?php for($i=1; $i<=8; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo ($editStudent && $editStudent['semester'] == $i) ? 'selected' : ''; ?>>Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Department *</label>
                <select name="department" required>
                    <option value="">Select Department</option>
                    <?php foreach($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['name']); ?>" 
                            <?php echo ($editStudent && $editStudent['department'] == $dept['name']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['name']); ?> (<?php echo htmlspecialchars($dept['code']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if(empty($departments)): ?>
                    <small style="color: #dc3545;">No departments found. Please add departments in Department Management first.</small>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Student Login Password * <?php echo $editStudent ? '(Leave empty to keep current password)' : ''; ?></label>
                <input type="text" name="password" <?php echo !$editStudent ? 'required' : ''; ?> placeholder="Enter password for student login" value="">
                <small>Password will be stored in plain text (no hashing) as requested.</small>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editStudent ? 'Update Student' : 'Add Student'; ?></button>
                <?php if($editStudent): ?>
                    <a href="student.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Student List Table -->
    <div class="table-card">
        <h2>📋 Student Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Name</th>
                        <th>Roll No</th>
                        <th>Phone</th>
                        <th>Semester</th>
                        <th>Department</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($students as $student): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                        <td><?php echo htmlspecialchars($student['rollno']); ?></td>
                        <td><?php echo htmlspecialchars($student['phone']); ?></td>
                        <td><?php echo $student['semester']; ?></td>
                        <td><?php echo htmlspecialchars($student['department']); ?></td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $student['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $student['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($students)): ?>
                    <tr><td colspan="7">No students found. Add your first student!</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>