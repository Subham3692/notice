<?php
// ==================== Updated header.php with Student Complaint menu ====================
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - College Management</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-link">📊 Dashboard</a>
                <a href="student.php" class="nav-link">👨‍🎓 Students</a>
                <a href="teacher.php" class="nav-link">👩‍🏫 Teachers</a>
                <a href="department.php" class="nav-link">🏛️ Departments</a>
                <a href="teachernotice.php" class="nav-link">📢 Teacher Notices</a>
                <a href="collagenotice.php" class="nav-link">🏛️ College Notices</a>
                <a href="class.php" class="nav-link">📚 Class Notices</a>
                <a href="departmentnotice.php" class="nav-link">🏛️ Dept Notices</a>
                <a href="event.php" class="nav-link">🎉 Events</a>
                <a href="banner.php" class="nav-link">🖼️ Image Gallery</a>
                <a href="studentcomplain.php" class="nav-link">📝 Student Complaints</a>
                <a href="logout.php" class="nav-link logout-link">🚪 Logout</a>
            </nav>
        </aside>
        <main class="main-content">