<?php
// ==================== footer.php ====================
?>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>