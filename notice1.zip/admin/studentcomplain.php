<?php
// ==================== studentcomplain.php ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$viewComplaint = null;
$editResponse = null;

// Handle Delete
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM student_complaints WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Complaint deleted successfully!";
    } else {
        $error = "Failed to delete complaint.";
    }
}

// Handle Status Update
if(isset($_GET['status']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    $validStatuses = ['pending', 'in_progress', 'resolved', 'rejected'];
    if(in_array($status, $validStatuses)) {
        $resolvedDate = ($status == 'resolved') ? date('Y-m-d') : null;
        $stmt = $pdo->prepare("UPDATE student_complaints SET status = ?, resolved_date = ? WHERE id = ?");
        if($stmt->execute([$status, $resolvedDate, $id])) {
            $message = "Complaint status updated to " . ucfirst(str_replace('_', ' ', $status)) . "!";
        } else {
            $error = "Failed to update status.";
        }
    }
}

// Handle Admin Response
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_response'])) {
    $complaint_id = $_POST['complaint_id'];
    $admin_response = trim($_POST['admin_response']);
    
    $stmt = $pdo->prepare("UPDATE student_complaints SET admin_response = ? WHERE id = ?");
    if($stmt->execute([$admin_response, $complaint_id])) {
        $message = "Response added successfully!";
        $editResponse = null;
    } else {
        $error = "Failed to add response.";
    }
}

// Get view data
if(isset($_GET['view'])) {
    $id = $_GET['view'];
    $stmt = $pdo->prepare("SELECT * FROM student_complaints WHERE id = ?");
    $stmt->execute([$id]);
    $viewComplaint = $stmt->fetch();
}

// Get response edit data
if(isset($_GET['respond'])) {
    $id = $_GET['respond'];
    $stmt = $pdo->prepare("SELECT * FROM student_complaints WHERE id = ?");
    $stmt->execute([$id]);
    $editResponse = $stmt->fetch();
}

// Fetch all complaints
$complaints = $pdo->query("SELECT * FROM student_complaints ORDER BY complaint_date DESC, id DESC")->fetchAll();

// Get counts by status
$pendingCount = $pdo->query("SELECT COUNT(*) FROM student_complaints WHERE status = 'pending'")->fetchColumn();
$inProgressCount = $pdo->query("SELECT COUNT(*) FROM student_complaints WHERE status = 'in_progress'")->fetchColumn();
$resolvedCount = $pdo->query("SELECT COUNT(*) FROM student_complaints WHERE status = 'resolved'")->fetchColumn();
$rejectedCount = $pdo->query("SELECT COUNT(*) FROM student_complaints WHERE status = 'rejected'")->fetchColumn();
?>

<div class="content-page">
    <div class="page-header">
        <h1>📝 Student Complaints Management</h1>
        <p>Manage and respond to student complaints and grievances</p>
    </div>
    
    <!-- Status Summary Cards -->
    <div class="stats-grid-small">
        <div class="stat-card-small pending">
            <div class="stat-icon">⏳</div>
            <div class="stat-info">
                <h3>Pending</h3>
                <p><?php echo $pendingCount; ?></p>
            </div>
        </div>
        <div class="stat-card-small in-progress">
            <div class="stat-icon">🔄</div>
            <div class="stat-info">
                <h3>In Progress</h3>
                <p><?php echo $inProgressCount; ?></p>
            </div>
        </div>
        <div class="stat-card-small resolved">
            <div class="stat-icon">✅</div>
            <div class="stat-info">
                <h3>Resolved</h3>
                <p><?php echo $resolvedCount; ?></p>
            </div>
        </div>
        <div class="stat-card-small rejected">
            <div class="stat-icon">❌</div>
            <div class="stat-info">
                <h3>Rejected</h3>
                <p><?php echo $rejectedCount; ?></p>
            </div>
        </div>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- View Complaint Modal/Section -->
    <?php if($viewComplaint): ?>
    <div class="modal-overlay" id="viewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>📋 Complaint Details</h2>
                <a href="studentcomplain.php" class="close-btn">&times;</a>
            </div>
            <div class="modal-body">
                <div class="detail-row">
                    <strong>Student Name:</strong> <?php echo htmlspecialchars($viewComplaint['student_name']); ?>
                </div>
                <div class="detail-row">
                    <strong>Roll Number:</strong> <?php echo htmlspecialchars($viewComplaint['student_rollno']); ?>
                </div>
                <div class="detail-row">
                    <strong>Phone:</strong> <?php echo htmlspecialchars($viewComplaint['student_phone']); ?>
                </div>
                <div class="detail-row">
                    <strong>Email:</strong> <?php echo htmlspecialchars($viewComplaint['student_email'] ?? 'Not provided'); ?>
                </div>
                <div class="detail-row">
                    <strong>Department:</strong> <?php echo htmlspecialchars($viewComplaint['department']); ?>
                </div>
                <div class="detail-row">
                    <strong>Semester:</strong> <?php echo $viewComplaint['semester']; ?>
                </div>
                <div class="detail-row">
                    <strong>Complaint Subject:</strong> <?php echo htmlspecialchars($viewComplaint['complaint_subject']); ?>
                </div>
                <div class="detail-row">
                    <strong>Complaint Message:</strong>
                    <div class="message-box"><?php echo nl2br(htmlspecialchars($viewComplaint['complaint_message'])); ?></div>
                </div>
                <div class="detail-row">
                    <strong>Complaint Date:</strong> <?php echo date('d-m-Y', strtotime($viewComplaint['complaint_date'])); ?>
                </div>
                <div class="detail-row">
                    <strong>Status:</strong>
                    <span class="status-badge status-<?php echo $viewComplaint['status']; ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $viewComplaint['status'])); ?>
                    </span>
                </div>
                <?php if($viewComplaint['admin_response']): ?>
                <div class="detail-row">
                    <strong>Admin Response:</strong>
                    <div class="response-box"><?php echo nl2br(htmlspecialchars($viewComplaint['admin_response'])); ?></div>
                </div>
                <?php endif; ?>
                <?php if($viewComplaint['resolved_date']): ?>
                <div class="detail-row">
                    <strong>Resolved Date:</strong> <?php echo date('d-m-Y', strtotime($viewComplaint['resolved_date'])); ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <a href="?respond=<?php echo $viewComplaint['id']; ?>" class="btn-primary">Add Response</a>
                <a href="studentcomplain.php" class="btn-secondary">Close</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Admin Response Modal -->
    <?php if($editResponse): ?>
    <div class="modal-overlay" id="responseModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>✏️ Add Response to Complaint</h2>
                <a href="studentcomplain.php" class="close-btn">&times;</a>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="complaint_id" value="<?php echo $editResponse['id']; ?>">
                    <div class="detail-row">
                        <strong>Student:</strong> <?php echo htmlspecialchars($editResponse['student_name']); ?>
                    </div>
                    <div class="detail-row">
                        <strong>Subject:</strong> <?php echo htmlspecialchars($editResponse['complaint_subject']); ?>
                    </div>
                    <div class="detail-row">
                        <strong>Current Status:</strong>
                        <span class="status-badge status-<?php echo $editResponse['status']; ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $editResponse['status'])); ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label>Admin Response *</label>
                        <textarea name="admin_response" required rows="5" placeholder="Enter your response to this complaint..."><?php echo htmlspecialchars($editResponse['admin_response'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Update Status</label>
                        <select name="status" onchange="updateStatus(this.value, <?php echo $editResponse['id']; ?>)">
                            <option value="pending" <?php echo $editResponse['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="in_progress" <?php echo $editResponse['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                            <option value="resolved" <?php echo $editResponse['status'] == 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                            <option value="rejected" <?php echo $editResponse['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="submit_response" class="btn-primary">Submit Response</button>
                    <a href="studentcomplain.php" class="btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function updateStatus(status, id) {
        window.location.href = '?status=' + status + '&id=' + id;
    }
    </script>
    <?php endif; ?>
    
    <!-- Complaints List Table -->
    <div class="table-card">
        <h2>📋 All Student Complaints</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Student Name</th>
                        <th>Roll No</th>
                        <th>Phone</th>
                        <th>Subject</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($complaints as $complaint): ?>
                    <tr class="status-row status-<?php echo $complaint['status']; ?>">
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($complaint['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($complaint['student_rollno']); ?></td>
                        <td><?php echo htmlspecialchars($complaint['student_phone']); ?></td>
                        <td><?php echo htmlspecialchars(substr($complaint['complaint_subject'], 0, 40)) . (strlen($complaint['complaint_subject']) > 40 ? '...' : ''); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $complaint['status']; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?>
                            </span>
                        </td>
                        <td><?php echo date('d-m-Y', strtotime($complaint['complaint_date'])); ?></td>
                        <td class="action-buttons">
                            <a href="?view=<?php echo $complaint['id']; ?>" class="btn-view">View</a>
                            <a href="?respond=<?php echo $complaint['id']; ?>" class="btn-respond">Respond</a>
                            <a href="?delete=<?php echo $complaint['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this complaint?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($complaints)): ?>
                    <tr>
                        <td colspan="8">No complaints found.<?php echo ' '; ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
/* Status Summary Cards */
.stats-grid-small {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card-small {
    background: white;
    border-radius: 16px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    border-left: 4px solid;
}

.stat-card-small.pending { border-left-color: #ffc107; }
.stat-card-small.in-progress { border-left-color: #17a2b8; }
.stat-card-small.resolved { border-left-color: #28a745; }
.stat-card-small.rejected { border-left-color: #dc3545; }

.stat-card-small .stat-icon {
    font-size: 36px;
}

.stat-card-small .stat-info h3 {
    font-size: 13px;
    color: #666;
    margin-bottom: 5px;
}

.stat-card-small .stat-info p {
    font-size: 28px;
    font-weight: 700;
    color: #1a1a2e;
}

/* Status Badges */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
}

.status-pending {
    background: #fff3cd;
    color: #856404;
}

.status-in_progress {
    background: #d1ecf1;
    color: #0c5460;
}

.status-resolved {
    background: #d4edda;
    color: #155724;
}

.status-rejected {
    background: #f8d7da;
    color: #721c24;
}

/* Row highlighting */
.status-row.status-pending {
    background-color: #fffef5;
}

.status-row.status-in_progress {
    background-color: #f0f9ff;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}

.modal-content {
    background: white;
    border-radius: 16px;
    max-width: 600px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    border-bottom: 1px solid #eee;
}

.modal-header h2 {
    font-size: 20px;
    margin: 0;
}

.close-btn {
    font-size: 28px;
    text-decoration: none;
    color: #999;
}

.close-btn:hover {
    color: #333;
}

.modal-body {
    padding: 24px;
}

.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #eee;
    display: flex;
    gap: 12px;
    justify-content: flex-end;
}

.detail-row {
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f0f0f0;
}

.detail-row strong {
    display: block;
    margin-bottom: 6px;
    color: #555;
    font-size: 13px;
}

.message-box, .response-box {
    background: #f8f9fa;
    padding: 12px;
    border-radius: 8px;
    margin-top: 6px;
    line-height: 1.5;
}

.btn-view {
    background: #17a2b8;
    color: white;
    padding: 4px 10px;
    border-radius: 4px;
    text-decoration: none;
    font-size: 12px;
    margin-right: 4px;
}

.btn-respond {
    background: #28a745;
    color: white;
    padding: 4px 10px;
    border-radius: 4px;
    text-decoration: none;
    font-size: 12px;
    margin-right: 4px;
}

.btn-view:hover {
    background: #138496;
}

.btn-respond:hover {
    background: #218838;
}

.data-table td {
    vertical-align: middle;
}

@media (max-width: 768px) {
    .stats-grid-small {
        grid-template-columns: repeat(2, 1fr);
    }
    .modal-content {
        width: 95%;
        margin: 20px;
    }
}
</style>

<?php require_once 'footer.php'; ?>