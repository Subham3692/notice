<?php
// ==================== event.php ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$editEvent = null;
$uploadDir = 'uploads/events/';

// Create upload directory if not exists
if(!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Delete event
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Get image path to delete file
    $stmt = $pdo->prepare("SELECT image_path FROM events WHERE id = ?");
    $stmt->execute([$id]);
    $event = $stmt->fetch();
    if($event && $event['image_path'] && file_exists($event['image_path'])) {
        unlink($event['image_path']);
    }
    $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Event deleted successfully!";
    } else {
        $error = "Failed to delete event.";
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
    $stmt->execute([$id]);
    $editEvent = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $event_text = trim($_POST['event_text']);
    $event_date = $_POST['event_date'];
    $link_url = trim($_POST['link_url']);
    
    // Handle image upload
    $image_path = null;
    if(isset($_FILES['event_image']) && $_FILES['event_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['event_image'];
        $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
        $targetPath = $uploadDir . $fileName;
        if(move_uploaded_file($file['tmp_name'], $targetPath)) {
            $image_path = $targetPath;
        } else {
            $error = "Failed to upload image.";
        }
    }
    
    if(isset($_POST['event_id']) && !empty($_POST['event_id'])) {
        // Update
        $id = $_POST['event_id'];
        if($image_path) {
            // Get old image and delete it
            $stmt = $pdo->prepare("SELECT image_path FROM events WHERE id = ?");
            $stmt->execute([$id]);
            $old = $stmt->fetch();
            if($old && $old['image_path'] && file_exists($old['image_path'])) {
                unlink($old['image_path']);
            }
            $stmt = $pdo->prepare("UPDATE events SET title=?, event_text=?, event_date=?, link_url=?, image_path=? WHERE id=?");
            $stmt->execute([$title, $event_text, $event_date, $link_url, $image_path, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE events SET title=?, event_text=?, event_date=?, link_url=? WHERE id=?");
            $stmt->execute([$title, $event_text, $event_date, $link_url, $id]);
        }
        $message = "Event updated successfully!";
        $editEvent = null;
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO events (title, event_text, event_date, link_url, image_path) VALUES (?, ?, ?, ?, ?)");
        if($stmt->execute([$title, $event_text, $event_date, $link_url, $image_path])) {
            $message = "Event added successfully!";
        } else {
            $error = "Failed to add event.";
        }
    }
}

// Fetch all events
$events = $pdo->query("SELECT * FROM events ORDER BY event_date DESC, id DESC")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>🎉 Events Management</h1>
        <p>Manage college events, workshops, seminars, and celebrations</p>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editEvent ? '✏️ Edit Event' : '➕ Add New Event'; ?></h2>
        <form method="POST" action="" class="admin-form" enctype="multipart/form-data">
            <?php if($editEvent): ?>
                <input type="hidden" name="event_id" value="<?php echo $editEvent['id']; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label>Event Title *</label>
                <input type="text" name="title" required placeholder="Enter event title" 
                       value="<?php echo $editEvent ? htmlspecialchars($editEvent['title']) : ''; ?>">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Event Date *</label>
                    <input type="date" name="event_date" required 
                           value="<?php echo $editEvent ? $editEvent['event_date'] : date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label>Event Image (Optional)</label>
                    <input type="file" name="event_image" accept="image/*">
                    <?php if($editEvent && $editEvent['image_path']): ?>
                        <div class="current-image">
                            <p>Current image:</p>
                            <img src="<?php echo $editEvent['image_path']; ?>" style="max-width: 100px; max-height: 100px; margin-top: 8px;">
                        </div>
                    <?php endif; ?>
                    <small>Supported formats: JPG, PNG, GIF. Max size: 5MB</small>
                </div>
            </div>
            
            <div class="form-group">
                <label>Event Description *</label>
                <textarea name="event_text" required rows="5" placeholder="Enter event details..."><?php echo $editEvent ? htmlspecialchars($editEvent['event_text']) : ''; ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Click Link URL (Optional)</label>
                <input type="url" name="link_url" placeholder="https://example.com/event-registration" 
                       value="<?php echo $editEvent ? htmlspecialchars($editEvent['link_url']) : ''; ?>">
                <small>Add registration link or more information link</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editEvent ? 'Update Event' : 'Add Event'; ?></button>
                <?php if($editEvent): ?>
                    <a href="event.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Events List Table -->
    <div class="table-card">
        <h2>📋 Events Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Event Title</th>
                        <th>Image</th>
                        <th>Event Text</th>
                        <th>Date</th>
                        <th>Link URL</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($events as $event): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><strong><?php echo htmlspecialchars($event['title']); ?></strong></td>
                        <td>
                            <?php if($event['image_path']): ?>
                                <a href="<?php echo $event['image_path']; ?>" target="_blank">
                                    <img src="<?php echo $event['image_path']; ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                </a>
                            <?php else: ?>
                                <span style="color: #999;">No image</span>
                            <?php endif; ?>
                        </td>
                        <td class="notice-text-cell"><?php echo htmlspecialchars(substr($event['event_text'], 0, 60)) . (strlen($event['event_text']) > 60 ? '...' : ''); ?></td>
                        <td><?php echo date('d-m-Y', strtotime($event['event_date'])); ?></td>
                        <td>
                            <?php if($event['link_url']): ?>
                                <a href="<?php echo htmlspecialchars($event['link_url']); ?>" target="_blank" class="link-btn">View Link</a>
                            <?php else: ?>
                                <span style="color: #999;">No link</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $event['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $event['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($events)): ?>
                    <tr>
                        <td colspan="7">No events found. Add your first event!<?php echo ' '; ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.notice-text-cell {
    max-width: 250px;
    white-space: normal;
    word-break: break-word;
    line-height: 1.4;
}
.current-image {
    margin-top: 8px;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 8px;
}
.current-image p {
    margin-bottom: 6px;
    font-size: 12px;
    color: #666;
}
.current-image img {
    border-radius: 6px;
    border: 1px solid #ddd;
}
textarea {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-family: inherit;
    font-size: 14px;
    resize: vertical;
}
textarea:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
}
small {
    font-size: 11px;
    color: #888;
    display: block;
    margin-top: 5px;
}
.data-table img {
    border-radius: 6px;
    border: 1px solid #eee;
    transition: transform 0.2s;
}
.data-table img:hover {
    transform: scale(1.5);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
.page-header p {
    color: #666;
    margin-top: 5px;
    font-size: 14px;
}
.link-btn {
    background: #28a745;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    text-decoration: none;
    font-size: 12px;
}
.link-btn:hover {
    background: #218838;
}
</style>

<?php require_once 'footer.php'; ?>