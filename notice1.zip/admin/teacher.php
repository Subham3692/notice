<?php
// ==================== Updated teacher.php with password field (plain text - no hashing) ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$editTeacher = null;

// Delete
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM teachers WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Teacher deleted successfully!";
    } else {
        $error = "Failed to delete teacher.";
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
    $stmt->execute([$id]);
    $editTeacher = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $department = trim($_POST['department']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']); // Plain text password - NO HASHING
    
    if(isset($_POST['teacher_id']) && !empty($_POST['teacher_id'])) {
        // Update - only update password if provided
        $id = $_POST['teacher_id'];
        if(!empty($password)) {
            $stmt = $pdo->prepare("UPDATE teachers SET name=?, department=?, phone=?, email=?, password=? WHERE id=?");
            $stmt->execute([$name, $department, $phone, $email, $password, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE teachers SET name=?, department=?, phone=?, email=? WHERE id=?");
            $stmt->execute([$name, $department, $phone, $email, $id]);
        }
        $message = "Teacher updated successfully!";
        $editTeacher = null;
    } else {
        // Insert - password is required for new teachers
        if(empty($password)) {
            $error = "Password is required for new teachers!";
        } else {
            $stmt = $pdo->prepare("INSERT INTO teachers (name, department, phone, email, password) VALUES (?, ?, ?, ?, ?)");
            if($stmt->execute([$name, $department, $phone, $email, $password])) {
                $message = "Teacher added successfully!";
            } else {
                $error = "Failed to add teacher. Email might already exist.";
            }
        }
    }
}

// Fetch all teachers (excluding password from display)
$teachers = $pdo->query("SELECT id, name, department, phone, email, created_at FROM teachers ORDER BY id DESC")->fetchAll();

// Fetch departments from departments table
$departments = $pdo->query("SELECT id, name, code FROM departments ORDER BY name")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>👩‍🏫 Teacher Management</h1>
        <p>Manage teacher records with login credentials</p>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editTeacher ? '✏️ Edit Teacher' : '➕ Add New Teacher'; ?></h2>
        <form method="POST" action="" class="admin-form">
            <?php if($editTeacher): ?>
                <input type="hidden" name="teacher_id" value="<?php echo $editTeacher['id']; ?>">
            <?php endif; ?>
            <div class="form-row">
                <div class="form-group">
                    <label>Teacher Name *</label>
                    <input type="text" name="name" required value="<?php echo $editTeacher ? htmlspecialchars($editTeacher['name']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Department *</label>
                    <select name="department" required>
                        <option value="">Select Department</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo htmlspecialchars($dept['name']); ?>" 
                                <?php echo ($editTeacher && $editTeacher['department'] == $dept['name']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dept['name']); ?> (<?php echo htmlspecialchars($dept['code']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if(empty($departments)): ?>
                        <small style="color: #dc3545;">No departments found. Please add departments in Department Management first.</small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="phone" required value="<?php echo $editTeacher ? htmlspecialchars($editTeacher['phone']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required value="<?php echo $editTeacher ? htmlspecialchars($editTeacher['email']) : ''; ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Teacher Login Password * <?php echo $editTeacher ? '(Leave empty to keep current password)' : ''; ?></label>
                <input type="text" name="password" <?php echo !$editTeacher ? 'required' : ''; ?> placeholder="Enter password for teacher login" value="">
                <small>Password will be stored in plain text (no hashing) as requested.</small>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editTeacher ? 'Update Teacher' : 'Add Teacher'; ?></button>
                <?php if($editTeacher): ?>
                    <a href="teacher.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Teacher List Table -->
    <div class="table-card">
        <h2>📋 Teacher Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th><th>Name</th><th>Department</th><th>Phone</th><th>Email</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($teachers as $teacher): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($teacher['name']); ?></td>
                        <td><?php echo htmlspecialchars($teacher['department']); ?></td>
                        <td><?php echo htmlspecialchars($teacher['phone']); ?></td>
                        <td><?php echo htmlspecialchars($teacher['email']); ?></td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $teacher['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $teacher['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($teachers)): ?>
                    <tr><td colspan="6">No teachers found. Add your first teacher!</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>