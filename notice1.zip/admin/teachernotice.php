<?php
// ==================== Updated teachernotice.php with dynamic departments ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$editNotice = null;
$uploadDir = 'uploads/notices/';

// Create upload directory if not exists
if(!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Delete notice
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Get image path to delete file
    $stmt = $pdo->prepare("SELECT image_path FROM teacher_notices WHERE id = ?");
    $stmt->execute([$id]);
    $notice = $stmt->fetch();
    if($notice && $notice['image_path'] && file_exists($notice['image_path'])) {
        unlink($notice['image_path']);
    }
    $stmt = $pdo->prepare("DELETE FROM teacher_notices WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Teacher notice deleted successfully!";
    } else {
        $error = "Failed to delete notice.";
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM teacher_notices WHERE id = ?");
    $stmt->execute([$id]);
    $editNotice = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher_id = $_POST['teacher_id'];
    $department = trim($_POST['department']);
    $semester = $_POST['semester'];
    $title = trim($_POST['title']);
    $notice_text = trim($_POST['notice_text']);
    $notice_date = $_POST['notice_date'];
    $link_url = trim($_POST['link_url']);
    
    // Handle image upload
    $image_path = null;
    if(isset($_FILES['notice_image']) && $_FILES['notice_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['notice_image'];
        $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
        $targetPath = $uploadDir . $fileName;
        if(move_uploaded_file($file['tmp_name'], $targetPath)) {
            $image_path = $targetPath;
        } else {
            $error = "Failed to upload image.";
        }
    }
    
    if(isset($_POST['notice_id']) && !empty($_POST['notice_id'])) {
        // Update
        $id = $_POST['notice_id'];
        if($image_path) {
            // Get old image and delete it
            $stmt = $pdo->prepare("SELECT image_path FROM teacher_notices WHERE id = ?");
            $stmt->execute([$id]);
            $old = $stmt->fetch();
            if($old && $old['image_path'] && file_exists($old['image_path'])) {
                unlink($old['image_path']);
            }
            $stmt = $pdo->prepare("UPDATE teacher_notices SET teacher_id=?, department=?, semester=?, title=?, notice_text=?, link_url=?, notice_date=?, image_path=? WHERE id=?");
            $stmt->execute([$teacher_id, $department, $semester, $title, $notice_text, $link_url, $notice_date, $image_path, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE teacher_notices SET teacher_id=?, department=?, semester=?, title=?, notice_text=?, link_url=?, notice_date=? WHERE id=?");
            $stmt->execute([$teacher_id, $department, $semester, $title, $notice_text, $link_url, $notice_date, $id]);
        }
        $message = "Teacher notice updated successfully!";
        $editNotice = null;
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO teacher_notices (teacher_id, department, semester, title, notice_text, link_url, notice_date, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if($stmt->execute([$teacher_id, $department, $semester, $title, $notice_text, $link_url, $notice_date, $image_path])) {
            $message = "Teacher notice added successfully!";
        } else {
            $error = "Failed to add notice.";
        }
    }
}

// Fetch all teacher notices with teacher names
$notices = $pdo->query("
    SELECT tn.*, t.name as teacher_name 
    FROM teacher_notices tn 
    LEFT JOIN teachers t ON tn.teacher_id = t.id 
    ORDER BY tn.id DESC
")->fetchAll();

// Fetch teachers for dropdown
$teachers = $pdo->query("SELECT id, name, department FROM teachers ORDER BY name")->fetchAll();

// Fetch departments from departments table
$departments = $pdo->query("SELECT id, name, code FROM departments ORDER BY name")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>📢 Teacher Notice Management</h1>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editNotice ? '✏️ Edit Teacher Notice' : '➕ Add New Teacher Notice'; ?></h2>
        <form method="POST" action="" class="admin-form" enctype="multipart/form-data">
            <?php if($editNotice): ?>
                <input type="hidden" name="notice_id" value="<?php echo $editNotice['id']; ?>">
            <?php endif; ?>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Select Teacher *</label>
                    <select name="teacher_id" required>
                        <option value="">Select Teacher</option>
                        <?php foreach($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['id']; ?>" 
                                <?php echo ($editNotice && $editNotice['teacher_id'] == $teacher['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher['name']); ?> (<?php echo htmlspecialchars($teacher['department']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if(empty($teachers)): ?>
                        <small style="color: #dc3545;">No teachers found. Please add teachers first.</small>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Department *</label>
                    <select name="department" required>
                        <option value="">Select Department</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo htmlspecialchars($dept['name']); ?>" 
                                <?php echo ($editNotice && $editNotice['department'] == $dept['name']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dept['name']); ?> (<?php echo htmlspecialchars($dept['code']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if(empty($departments)): ?>
                        <small style="color: #dc3545;">No departments found. Please add departments in Department Management first.</small>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Semester *</label>
                    <select name="semester" required>
                        <option value="">Select Semester</option>
                        <?php for($i=1; $i<=8; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo ($editNotice && $editNotice['semester'] == $i) ? 'selected' : ''; ?>>Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Notice Date *</label>
                    <input type="date" name="notice_date" required value="<?php echo $editNotice ? $editNotice['notice_date'] : date('Y-m-d'); ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label>Notice Title *</label>
                <input type="text" name="title" required placeholder="Enter notice title" value="<?php echo $editNotice ? htmlspecialchars($editNotice['title']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>Notice Message *</label>
                <textarea name="notice_text" required rows="4" placeholder="Enter notice details..."><?php echo $editNotice ? htmlspecialchars($editNotice['notice_text']) : ''; ?></textarea>
            </div>

            <div class="form-group">
                <label>Click Link URL (Optional)</label>
                <input type="url" name="link_url" placeholder="https://example.com/event-registration" 
                       value="<?php echo $editNotice ? htmlspecialchars($editNotice['link_url']) : ''; ?>">
                <small>Add registration link or more information link</small>
            </div>
            
            <div class="form-group">
                <label>Notice Image (Optional)</label>
                <input type="file" name="notice_image" accept="image/*">
                <?php if($editNotice && $editNotice['image_path']): ?>
                    <div class="current-image">
                        <p>Current image:</p>
                        <img src="<?php echo $editNotice['image_path']; ?>" style="max-width: 100px; max-height: 100px; margin-top: 8px;">
                    </div>
                <?php endif; ?>
                <small>Supported formats: JPG, PNG, GIF. Max size: 5MB</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editNotice ? 'Update Notice' : 'Add Notice'; ?></button>
                <?php if($editNotice): ?>
                    <a href="teachernotice.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Notices List Table -->
    <div class="table-card">
        <h2>📋 Teacher Notices Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Teacher Name</th>
                        <th>Department</th>
                        <th>Semester</th>
                        <th>Notice Title</th>
                        <th>Image</th>
                        <th>Notice Text</th>
                        <th>Link URL</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($notices as $notice): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($notice['teacher_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($notice['department']); ?></td>
                        <td><?php echo $notice['semester']; ?></td>
                        <td><?php echo htmlspecialchars($notice['title']); ?></td>
                        <td>
                            <?php if($notice['image_path']): ?>
                                <a href="<?php echo $notice['image_path']; ?>" target="_blank">
                                    <img src="<?php echo $notice['image_path']; ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                </a>
                            <?php else: ?>
                                <span style="color: #999;">No image</span>
                            <?php endif; ?>
                        </td>
                        <td class="notice-text-cell"><?php echo htmlspecialchars(substr($notice['notice_text'], 0, 50)) . (strlen($notice['notice_text']) > 50 ? '...' : ''); ?></td>
                        <td>
                            <?php if($notice['link_url']): ?>
                                <a href="<?php echo htmlspecialchars($notice['link_url']); ?>" target="_blank" class="link-btn">View Link</a>
                            <?php else: ?>
                                <span style="color: #999;">No link</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('d-m-Y', strtotime($notice['notice_date'])); ?></td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $notice['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $notice['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($notices)): ?>
                    <tr>
                        <td colspan="9">No teacher notices found. Add your first notice!</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.notice-text-cell {
    max-width: 200px;
    white-space: normal;
    word-break: break-word;
}
.current-image {
    margin-top: 8px;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 8px;
}
textarea {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-family: inherit;
    resize: vertical;
}
</style>

<?php require_once 'footer.php'; ?>