<?php
// ==================== department.php ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$editDept = null;

// Delete department
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Check if department is being used in students or teachers
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE department = (SELECT name FROM departments WHERE id = ?)");
    $stmt->execute([$id]);
    $studentCount = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE department = (SELECT name FROM departments WHERE id = ?)");
    $stmt->execute([$id]);
    $teacherCount = $stmt->fetchColumn();
    
    if($studentCount > 0 || $teacherCount > 0) {
        $error = "Cannot delete department. It has $studentCount student(s) and $teacherCount teacher(s) assigned.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM departments WHERE id = ?");
        if($stmt->execute([$id])) {
            $message = "Department deleted successfully!";
        } else {
            $error = "Failed to delete department.";
        }
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE id = ?");
    $stmt->execute([$id]);
    $editDept = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $code = strtoupper(trim($_POST['code']));
    $description = trim($_POST['description']);
    
    if(isset($_POST['dept_id']) && !empty($_POST['dept_id'])) {
        // Update
        $id = $_POST['dept_id'];
        $stmt = $pdo->prepare("UPDATE departments SET name=?, code=?, description=? WHERE id=?");
        if($stmt->execute([$name, $code, $description, $id])) {
            $message = "Department updated successfully!";
            $editDept = null;
        } else {
            $error = "Failed to update department. Name or code might already exist.";
        }
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO departments (name, code, description) VALUES (?, ?, ?)");
        if($stmt->execute([$name, $code, $description])) {
            $message = "Department added successfully!";
        } else {
            $error = "Failed to add department. Name or code might already exist.";
        }
    }
}

// Fetch all departments
$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>🏛️ Department Management</h1>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editDept ? '✏️ Edit Department' : '➕ Add New Department'; ?></h2>
        <form method="POST" action="" class="admin-form">
            <?php if($editDept): ?>
                <input type="hidden" name="dept_id" value="<?php echo $editDept['id']; ?>">
            <?php endif; ?>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Department Name *</label>
                    <input type="text" name="name" required placeholder="e.g., Computer Science Engineering" 
                           value="<?php echo $editDept ? htmlspecialchars($editDept['name']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Department Code *</label>
                    <input type="text" name="code" required placeholder="e.g., CSE" maxlength="20"
                           value="<?php echo $editDept ? htmlspecialchars($editDept['code']) : ''; ?>">
                    <small>Unique code for the department (e.g., CSE, BCA, ECE)</small>
                </div>
            </div>
            
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="3" placeholder="Enter department description..."><?php echo $editDept ? htmlspecialchars($editDept['description']) : ''; ?></textarea>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editDept ? 'Update Department' : 'Add Department'; ?></button>
                <?php if($editDept): ?>
                    <a href="department.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Departments List Table -->
    <div class="table-card">
        <h2>📋 Departments Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Department Name</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Created Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($departments as $dept): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($dept['name']); ?></td>
                        <td><strong><?php echo htmlspecialchars($dept['code']); ?></strong></td>
                        <td><?php echo htmlspecialchars(substr($dept['description'], 0, 60)) . (strlen($dept['description']) > 60 ? '...' : ''); ?></td>
                        <td><?php echo date('d-m-Y', strtotime($dept['created_at'])); ?></td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $dept['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $dept['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure? This will affect students/teachers using this department.')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($departments)): ?>
                    <tr>
                        <td colspan="6">No departments found. Add your first department!</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>