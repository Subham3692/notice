<?php
// ==================== class.php ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$editNotice = null;
$uploadDir = 'uploads/class_notices/';

// Create upload directory if not exists
if(!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Delete notice
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Get image path to delete file
    $stmt = $pdo->prepare("SELECT image_path FROM class_notices WHERE id = ?");
    $stmt->execute([$id]);
    $notice = $stmt->fetch();
    if($notice && $notice['image_path'] && file_exists($notice['image_path'])) {
        unlink($notice['image_path']);
    }
    $stmt = $pdo->prepare("DELETE FROM class_notices WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Class notice deleted successfully!";
    } else {
        $error = "Failed to delete notice.";
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM class_notices WHERE id = ?");
    $stmt->execute([$id]);
    $editNotice = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $semester = (int)$_POST['semester'];
    $department = trim($_POST['department']);
    $title = trim($_POST['title']);
    $notice_text = trim($_POST['notice_text']);
    $notice_date = $_POST['notice_date'];
    $link_url = trim($_POST['link_url']);
    
    // Handle image upload
    $image_path = null;
    if(isset($_FILES['notice_image']) && $_FILES['notice_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['notice_image'];
        $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
        $targetPath = $uploadDir . $fileName;
        if(move_uploaded_file($file['tmp_name'], $targetPath)) {
            $image_path = $targetPath;
        } else {
            $error = "Failed to upload image.";
        }
    }
    
    if(isset($_POST['notice_id']) && !empty($_POST['notice_id'])) {
        // Update
        $id = $_POST['notice_id'];
        if($image_path) {
            // Get old image and delete it
            $stmt = $pdo->prepare("SELECT image_path FROM class_notices WHERE id = ?");
            $stmt->execute([$id]);
            $old = $stmt->fetch();
            if($old && $old['image_path'] && file_exists($old['image_path'])) {
                unlink($old['image_path']);
            }
            $stmt = $pdo->prepare("UPDATE class_notices SET semester=?, department=?, title=?, notice_text=?, link_url=?, notice_date=?, image_path=? WHERE id=?");
            $stmt->execute([$semester, $department, $title, $notice_text, $link_url, $notice_date, $image_path, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE class_notices SET semester=?, department=?, title=?, notice_text=?, link_url=?, notice_date=? WHERE id=?");
            $stmt->execute([$semester, $department, $title, $notice_text, $link_url, $notice_date, $id]);
        }
        $message = "Class notice updated successfully!";
        $editNotice = null;
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO class_notices (semester, department, title, notice_text, link_url, notice_date, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if($stmt->execute([$semester, $department, $title, $notice_text, $link_url, $notice_date, $image_path])) {
            $message = "Class notice added successfully!";
        } else {
            $error = "Failed to add notice.";
        }
    }
}

// Fetch all class notices
$notices = $pdo->query("SELECT * FROM class_notices ORDER BY id DESC")->fetchAll();

// Fetch departments for dropdown
$departments = $pdo->query("SELECT name, code FROM departments ORDER BY name")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>📚 Class Notice Management</h1>
        <p>Manage notices for specific semesters and departments</p>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editNotice ? '✏️ Edit Class Notice' : '➕ Add New Class Notice'; ?></h2>
        <form method="POST" action="" class="admin-form" enctype="multipart/form-data">
            <?php if($editNotice): ?>
                <input type="hidden" name="notice_id" value="<?php echo $editNotice['id']; ?>">
            <?php endif; ?>
            
            <div class="form-row">
                <div class="form-group">
                    <label>School Semester *</label>
                    <select name="semester" required>
                        <option value="">Select Semester</option>
                        <?php for($i=1; $i<=8; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo ($editNotice && $editNotice['semester'] == $i) ? 'selected' : ''; ?>>
                                Semester <?php echo $i; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Department *</label>
                    <select name="department" required>
                        <option value="">Select Department</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo htmlspecialchars($dept['name']); ?>" 
                                <?php echo ($editNotice && $editNotice['department'] == $dept['name']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dept['name']); ?> (<?php echo $dept['code']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label>Notice Title *</label>
                <input type="text" name="title" required placeholder="Enter notice title" 
                       value="<?php echo $editNotice ? htmlspecialchars($editNotice['title']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>Notice Message *</label>
                <textarea name="notice_text" required rows="5" placeholder="Enter notice details..."><?php echo $editNotice ? htmlspecialchars($editNotice['notice_text']) : ''; ?></textarea>
            </div>

            <div class="form-group">
                <label>Click Link URL (Optional)</label>
                <input type="url" name="link_url" placeholder="https://example.com/event-registration" value="<?php echo $editNotice ? htmlspecialchars($editNotice['link_url']) : ''; ?>">
                <small>Add registration link or more information link</small>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Notice Date *</label>
                    <input type="date" name="notice_date" required 
                           value="<?php echo $editNotice ? $editNotice['notice_date'] : date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label>Notice Image (Optional)</label>
                    <input type="file" name="notice_image" accept="image/*">
                    <?php if($editNotice && $editNotice['image_path']): ?>
                        <div class="current-image">
                            <p>Current image:</p>
                            <img src="<?php echo $editNotice['image_path']; ?>" style="max-width: 100px; max-height: 100px; margin-top: 8px;">
                        </div>
                    <?php endif; ?>
                    <small>Supported formats: JPG, PNG, GIF. Max size: 5MB</small>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editNotice ? 'Update Notice' : 'Add Notice'; ?></button>
                <?php if($editNotice): ?>
                    <a href="class.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Notices List Table -->
    <div class="table-card">
        <h2>📋 Class Notices Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Semester</th>
                        <th>Department</th>
                        <th>Notice Title</th>
                        <th>Link URL</th>
                        <th>Image</th>
                        <th>Notice Text</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($notices as $notice): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><strong>Semester <?php echo $notice['semester']; ?></strong></td>
                        <td><?php echo htmlspecialchars($notice['department']); ?></td>
                        <td><?php echo htmlspecialchars($notice['title']); ?></td>
                        <td>
                            <?php if($notice['link_url']): ?>
                                <a href="<?php echo htmlspecialchars($notice['link_url']); ?>" target="_blank" class="link-btn">View Link</a>
                            <?php else: ?>
                                <span style="color: #999;">No link</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($notice['image_path']): ?>
                                <a href="<?php echo $notice['image_path']; ?>" target="_blank">
                                    <img src="<?php echo $notice['image_path']; ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                </a>
                            <?php else: ?>
                                <span style="color: #999;">No image</span>
                            <?php endif; ?>
                        </td>
                        <td class="notice-text-cell"><?php echo htmlspecialchars(substr($notice['notice_text'], 0, 60)) . (strlen($notice['notice_text']) > 60 ? '...' : ''); ?></td>
                        <td><?php echo date('d-m-Y', strtotime($notice['notice_date'])); ?></td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $notice['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $notice['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($notices)): ?>
                    <tr>
                        <td colspan="8">No class notices found. Add your first class notice!</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.notice-text-cell {
    max-width: 250px;
    white-space: normal;
    word-break: break-word;
    line-height: 1.4;
}
.current-image {
    margin-top: 8px;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 8px;
}
.current-image p {
    margin-bottom: 6px;
    font-size: 12px;
    color: #666;
}
.current-image img {
    border-radius: 6px;
    border: 1px solid #ddd;
}
textarea {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-family: inherit;
    font-size: 14px;
    resize: vertical;
}
textarea:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
}
small {
    font-size: 11px;
    color: #888;
    display: block;
    margin-top: 5px;
}
.data-table img {
    border-radius: 6px;
    border: 1px solid #eee;
    transition: transform 0.2s;
}
.data-table img:hover {
    transform: scale(1.5);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
.page-header p {
    color: #666;
    margin-top: 5px;
    font-size: 14px;
}
</style>

<?php require_once 'footer.php'; ?>