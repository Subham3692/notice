<?php
// ==================== dashboard.php (Teacher Full Admin Access) ====================
session_start();
require_once 'database.php';

// Check if teacher is logged in
if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Set user info
$user_name = $_SESSION['teacher_name'];
$teacher_id = $_SESSION['teacher_id'];
$teacher_department = $_SESSION['teacher_department'];

// Get all counts (Full access for teacher)
$studentCount = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$teacherCount = $pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$departmentCount = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
$teacherNoticeCount = $pdo->query("SELECT COUNT(*) FROM teacher_notices")->fetchColumn();
$collegeNoticeCount = $pdo->query("SELECT COUNT(*) FROM college_notices")->fetchColumn();
$classNoticeCount = $pdo->query("SELECT COUNT(*) FROM class_notices")->fetchColumn();
$departmentNoticeCount = $pdo->query("SELECT COUNT(*) FROM department_notices")->fetchColumn();
$eventCount = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
$bannerCount = $pdo->query("SELECT COUNT(*) FROM banners")->fetchColumn();
$complaintCount = $pdo->query("SELECT COUNT(*) FROM student_complaints")->fetchColumn();
$pendingComplaintCount = $pdo->query("SELECT COUNT(*) FROM student_complaints WHERE status = 'pending'")->fetchColumn();

// Get recent data
$recentStudents = $pdo->query("SELECT * FROM students ORDER BY id DESC LIMIT 5")->fetchAll();
$recentTeachers = $pdo->query("SELECT * FROM teachers ORDER BY id DESC LIMIT 5")->fetchAll();
$recentDepartments = $pdo->query("SELECT * FROM departments ORDER BY id DESC LIMIT 5")->fetchAll();
$recentTeacherNotices = $pdo->query("
    SELECT tn.*, t.name as teacher_name 
    FROM teacher_notices tn 
    LEFT JOIN teachers t ON tn.teacher_id = t.id 
    ORDER BY tn.id DESC LIMIT 5
")->fetchAll();
$recentCollegeNotices = $pdo->query("SELECT * FROM college_notices ORDER BY id DESC LIMIT 5")->fetchAll();
$recentClassNotices = $pdo->query("SELECT * FROM class_notices ORDER BY id DESC LIMIT 5")->fetchAll();
$recentDepartmentNotices = $pdo->query("SELECT * FROM department_notices ORDER BY id DESC LIMIT 5")->fetchAll();
$upcomingEvents = $pdo->query("SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 5")->fetchAll();
$recentBanners = $pdo->query("SELECT * FROM banners ORDER BY id DESC LIMIT 5")->fetchAll();
$recentComplaints = $pdo->query("SELECT * FROM student_complaints ORDER BY complaint_date DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - College Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f0f2f5;
        }
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 280px;
            background: #1a1a2e;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 24px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-header h2 {
            font-size: 20px;
        }
        .user-info {
            padding: 20px;
            background: rgba(255,255,255,0.1);
            margin: 20px;
            border-radius: 12px;
            text-align: center;
        }
        .user-info h3 {
            font-size: 16px;
            margin-bottom: 5px;
        }
        .user-info p {
            font-size: 12px;
            opacity: 0.8;
        }
        .user-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            margin-top: 8px;
            background: #28a745;
            color: white;
        }
        .sidebar-nav {
            padding: 20px 0;
        }
        .nav-link {
            display: block;
            padding: 12px 24px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s;
        }
        .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            padding-left: 28px;
        }
        .logout-link {
            margin-top: 40px;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 20px;
            color: #ff6b6b;
        }
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }
        .welcome-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 16px;
            margin-bottom: 30px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .stat-icon {
            font-size: 40px;
        }
        .stat-info h3 {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
        }
        .stat-info p {
            font-size: 28px;
            font-weight: 700;
            color: #1a1a2e;
        }
        .pending-badge {
            display: inline-block;
            background: #ffc107;
            color: #856404;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 10px;
            margin-top: 5px;
        }
        .recent-sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
        }
        .recent-box {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .recent-box h2 {
            font-size: 18px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th, .data-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
            font-size: 13px;
        }
        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .status-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 500;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-in_progress { background: #d1ecf1; color: #0c5460; }
        .status-resolved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .small-link {
            background: #28a745;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 11px;
        }
        .small-link:hover {
            background: #218838;
        }
        @media (max-width: 768px) {
            .sidebar { width: 200px; }
            .main-content { margin-left: 200px; padding: 20px; }
            .recent-sections { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Teacher Panel</h2>
            </div>
            <div class="user-info">
                <h3><?php echo htmlspecialchars($user_name); ?></h3>
                <p><?php echo htmlspecialchars($teacher_department); ?></p>
                <span class="user-badge">Teacher Access</span>
            </div>
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-link">📊 Dashboard</a>
                <a href="student.php" class="nav-link">👨‍🎓 Students</a>
                <a href="teacher.php" class="nav-link">👩‍🏫 Teachers</a>
                <a href="department.php" class="nav-link">🏛️ Departments</a>
                <a href="teachernotice.php" class="nav-link">📢 Teacher Notices</a>
                <a href="collagenotice.php" class="nav-link">🏛️ College Notices</a>
                <a href="class.php" class="nav-link">📚 Class Notices</a>
                <a href="departmentnotice.php" class="nav-link">🏛️ Dept Notices</a>
                <a href="event.php" class="nav-link">🎉 Events</a>
                <a href="banner.php" class="nav-link">🖼️ Image Gallery</a>
                <a href="studentcomplain.php" class="nav-link">📝 Complaints</a>
                <a href="logout.php" class="nav-link logout-link">🚪 Logout</a>
            </nav>
        </aside>
        
        <main class="main-content">
            <div class="welcome-card">
                <h1>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h1>
                <p>You are logged in as Teacher | Department of <?php echo htmlspecialchars($teacher_department); ?> | <?php echo date('l, d F Y'); ?></p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-icon">👨‍🎓</div><div class="stat-info"><h3>Total Students</h3><p><?php echo $studentCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">👩‍🏫</div><div class="stat-info"><h3>Total Teachers</h3><p><?php echo $teacherCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">🏛️</div><div class="stat-info"><h3>Departments</h3><p><?php echo $departmentCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">📢</div><div class="stat-info"><h3>Teacher Notices</h3><p><?php echo $teacherNoticeCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">🏛️</div><div class="stat-info"><h3>College Notices</h3><p><?php echo $collegeNoticeCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">📚</div><div class="stat-info"><h3>Class Notices</h3><p><?php echo $classNoticeCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">🏛️</div><div class="stat-info"><h3>Dept Notices</h3><p><?php echo $departmentNoticeCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">🎉</div><div class="stat-info"><h3>Events</h3><p><?php echo $eventCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">🖼️</div><div class="stat-info"><h3>Banners</h3><p><?php echo $bannerCount; ?></p></div></div>
                <div class="stat-card"><div class="stat-icon">📝</div><div class="stat-info"><h3>Complaints</h3><p><?php echo $complaintCount; ?><?php if($pendingComplaintCount > 0): ?><br><small class="pending-badge"><?php echo $pendingComplaintCount; ?> pending</small><?php endif; ?></p></div></div>
            </div>
            
            <div class="recent-sections">
                <div class="recent-box"><h2>📚 Recent Students</h2><table class="data-table"><thead><tr><th>Name</th><th>Roll No</th><th>Department</th></tr></thead><tbody><?php foreach($recentStudents as $student): ?><tr><td><?php echo htmlspecialchars($student['name']); ?></td><td><?php echo htmlspecialchars($student['rollno']); ?></td><td><?php echo htmlspecialchars($student['department']); ?></td></tr><?php endforeach; ?><?php if(empty($recentStudents)): ?><td><td colspan="3">No students found</td><?php endif; ?></tbody></table></div>
                
                <div class="recent-box"><h2>📖 Recent Teachers</h2><table class="data-table"><thead><tr><th>Name</th><th>Department</th><th>Email</th></tr></thead><tbody><?php foreach($recentTeachers as $teacher): ?><tr><td><?php echo htmlspecialchars($teacher['name']); ?></td><td><?php echo htmlspecialchars($teacher['department']); ?></td><td><?php echo htmlspecialchars($teacher['email']); ?></td></tr><?php endforeach; ?><?php if(empty($recentTeachers)): ?><tr><td colspan="3">No teachers found</td><?php endif; ?></tbody></table></div>
                
                <div class="recent-box"><h2>📢 Recent Teacher Notices</h2><table class="data-table"><thead><tr><th>Teacher</th><th>Title</th><th>Date</th></tr></thead><tbody><?php foreach($recentTeacherNotices as $notice): ?><tr><td><?php echo htmlspecialchars($notice['teacher_name'] ?? 'N/A'); ?></td><td><?php echo htmlspecialchars(substr($notice['title'], 0, 30)); ?></td><td><?php echo date('d-m-Y', strtotime($notice['notice_date'])); ?></td></tr><?php endforeach; ?><?php if(empty($recentTeacherNotices)): ?><td><td colspan="3">No notices found</td><?php endif; ?></tbody></table></div>
                
                <div class="recent-box"><h2>🏛️ Recent College Notices</h2><table class="data-table"><thead><tr><th>Title</th><th>Date</th></tr></thead><tbody><?php foreach($recentCollegeNotices as $notice): ?><td><?php echo htmlspecialchars(substr($notice['title'], 0, 40)); ?></td><td><?php echo date('d-m-Y', strtotime($notice['notice_date'])); ?></td><?php endforeach; ?><?php if(empty($recentCollegeNotices)): ?><tr><td colspan="2">No notices found</td><?php endif; ?></tbody></table></div>
                
                <div class="recent-box"><h2>🎉 Upcoming Events</h2><table class="data-table"><thead><tr><th>Event Title</th><th>Date</th><th>Link</th></tr></thead><tbody><?php foreach($upcomingEvents as $event): ?><tr><td><?php echo htmlspecialchars(substr($event['title'], 0, 35)); ?></td><td><?php echo date('d-m-Y', strtotime($event['event_date'])); ?></td><td><?php if($event['link_url']): ?><a href="<?php echo $event['link_url']; ?>" target="_blank" class="small-link">View</a><?php else: ?>-<?php endif; ?></td></tr><?php endforeach; ?><?php if(empty($upcomingEvents)): ?><tr><td colspan="3">No upcoming events</td></tr><?php endif; ?></tbody></table></div>
                
                <div class="recent-box"><h2>📝 Recent Complaints</h2><table class="data-table"><thead><tr><th>Student</th><th>Subject</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($recentComplaints as $complaint): ?><tr><td><?php echo htmlspecialchars($complaint['student_name']); ?></td><td><?php echo htmlspecialchars(substr($complaint['complaint_subject'], 0, 25)); ?></td><td><span class="status-badge status-<?php echo $complaint['status']; ?>"><?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?></span></td><td><?php echo date('d-m-Y', strtotime($complaint['complaint_date'])); ?></td></tr><?php endforeach; ?><?php if(empty($recentComplaints)): ?><tr><td colspan="4">No complaints found</td></tr><?php endif; ?></tbody></table></div>
            </div>
        </main>
    </div>
</body>
</html>