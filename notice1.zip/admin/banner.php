<?php
// ==================== banner.php (Image Gallery) ====================
require_once 'header.php';
require_once 'database.php';

if(!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';
$editBanner = null;
$uploadDir = 'uploads/banners/';

// Create upload directory if not exists
if(!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Delete banner
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Get image path to delete file
    $stmt = $pdo->prepare("SELECT image_path FROM banners WHERE id = ?");
    $stmt->execute([$id]);
    $banner = $stmt->fetch();
    if($banner && $banner['image_path'] && file_exists($banner['image_path'])) {
        unlink($banner['image_path']);
    }
    $stmt = $pdo->prepare("DELETE FROM banners WHERE id = ?");
    if($stmt->execute([$id])) {
        $message = "Banner image deleted successfully!";
    } else {
        $error = "Failed to delete banner.";
    }
}

// Get edit data
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM banners WHERE id = ?");
    $stmt->execute([$id]);
    $editBanner = $stmt->fetch();
}

// Handle Add/Update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $link_url = trim($_POST['link_url']);
    
    // Handle image upload (required for new banners)
    $image_path = null;
    $hasImage = false;
    
    if(isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['banner_image'];
        $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
        $targetPath = $uploadDir . $fileName;
        if(move_uploaded_file($file['tmp_name'], $targetPath)) {
            $image_path = $targetPath;
            $hasImage = true;
        } else {
            $error = "Failed to upload image.";
        }
    }
    
    if(isset($_POST['banner_id']) && !empty($_POST['banner_id'])) {
        // Update
        $id = $_POST['banner_id'];
        if($hasImage) {
            // Get old image and delete it
            $stmt = $pdo->prepare("SELECT image_path FROM banners WHERE id = ?");
            $stmt->execute([$id]);
            $old = $stmt->fetch();
            if($old && $old['image_path'] && file_exists($old['image_path'])) {
                unlink($old['image_path']);
            }
            $stmt = $pdo->prepare("UPDATE banners SET title=?, link_url=?, image_path=? WHERE id=?");
            $stmt->execute([$title, $link_url, $image_path, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE banners SET title=?, link_url=? WHERE id=?");
            $stmt->execute([$title, $link_url, $id]);
        }
        $message = "Banner updated successfully!";
        $editBanner = null;
    } else {
        // Insert - image is required
        if(!$hasImage) {
            $error = "Please select an image for the banner.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO banners (title, image_path, link_url) VALUES (?, ?, ?)");
            if($stmt->execute([$title, $image_path, $link_url])) {
                $message = "Banner added successfully!";
            } else {
                $error = "Failed to add banner.";
            }
        }
    }
}

// Fetch all banners
$banners = $pdo->query("SELECT * FROM banners ORDER BY id DESC")->fetchAll();
?>

<div class="content-page">
    <div class="page-header">
        <h1>🖼️ Banner / Image Gallery Management</h1>
        <p>Manage banner images for homepage and gallery sections</p>
    </div>
    
    <?php if($message): ?>
        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Add/Edit Form -->
    <div class="form-card">
        <h2><?php echo $editBanner ? '✏️ Edit Banner Image' : '➕ Add New Banner Image'; ?></h2>
        <form method="POST" action="" class="admin-form" enctype="multipart/form-data">
            <?php if($editBanner): ?>
                <input type="hidden" name="banner_id" value="<?php echo $editBanner['id']; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label>Banner Title *</label>
                <input type="text" name="title" required placeholder="Enter banner title" 
                       value="<?php echo $editBanner ? htmlspecialchars($editBanner['title']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>Banner Image * <?php echo $editBanner ? '(Leave empty to keep current)' : ''; ?></label>
                <input type="file" name="banner_image" accept="image/*" <?php echo !$editBanner ? 'required' : ''; ?>>
                <?php if($editBanner && $editBanner['image_path']): ?>
                    <div class="current-image">
                        <p>Current image:</p>
                        <img src="<?php echo $editBanner['image_path']; ?>" style="max-width: 150px; max-height: 100px; margin-top: 8px; border-radius: 8px;">
                    </div>
                <?php endif; ?>
                <small>Supported formats: JPG, PNG, GIF, WebP. Recommended size: 1200x400px</small>
            </div>
            
            <div class="form-group">
                <label>Click Link URL (Optional)</label>
                <input type="url" name="link_url" placeholder="https://example.com/page" 
                       value="<?php echo $editBanner ? htmlspecialchars($editBanner['link_url']) : ''; ?>">
                <small>Add URL where users will be redirected when clicking the banner</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $editBanner ? 'Update Banner' : 'Add Banner'; ?></button>
                <?php if($editBanner): ?>
                    <a href="banner.php" class="btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Banners List Table -->
    <div class="table-card">
        <h2>📋 Banner Gallery</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Banner Title</th>
                        <th>Image</th>
                        <th>Preview</th>
                        <th>URL Link</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($banners as $banner): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><strong><?php echo htmlspecialchars($banner['title']); ?></strong></td>
                        <td>
                            <?php if($banner['image_path']): ?>
                                <a href="<?php echo $banner['image_path']; ?>" target="_blank">
                                    <?php echo basename($banner['image_path']); ?>
                                </a>
                            <?php else: ?>
                                <span style="color: #999;">No image</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($banner['image_path']): ?>
                                <img src="<?php echo $banner['image_path']; ?>" style="width: 80px; height: 50px; object-fit: cover; border-radius: 4px;">
                            <?php else: ?>
                                <span style="color: #999;">No preview</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($banner['link_url']): ?>
                                <a href="<?php echo htmlspecialchars($banner['link_url']); ?>" target="_blank" class="link-btn">Visit Link</a>
                            <?php else: ?>
                                <span style="color: #999;">No link</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-buttons">
                            <a href="?edit=<?php echo $banner['id']; ?>" class="btn-edit">Edit</a>
                            <a href="?delete=<?php echo $banner['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure? This will permanently delete the image.')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($banners)): ?>
                    <tr>
                        <td colspan="6">No banner images found. Add your first banner image!<?php echo ' '; ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.current-image {
    margin-top: 8px;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 8px;
}
.current-image p {
    margin-bottom: 6px;
    font-size: 12px;
    color: #666;
}
.current-image img {
    border-radius: 6px;
    border: 1px solid #ddd;
}
.link-btn {
    background: #007bff;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    text-decoration: none;
    font-size: 12px;
}
.link-btn:hover {
    background: #0056b3;
}
.data-table img {
    border-radius: 6px;
    border: 1px solid #eee;
}
.page-header p {
    color: #666;
    margin-top: 5px;
    font-size: 14px;
}
</style>

<?php require_once 'footer.php'; ?>