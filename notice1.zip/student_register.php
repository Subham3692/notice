<?php
session_start();
require_once 'admin/database.php';

$error = '';
$success = '';

// Fetch departments
$departments = $pdo->query("SELECT id, name, code FROM departments ORDER BY name")->fetchAll();

if($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name']);
    $rollno = trim($_POST['rollno']);
    $phone = trim($_POST['phone']);
    $semester = $_POST['semester'];
    $department = $_POST['department'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check duplicate rollno
    $check = $pdo->prepare("SELECT id FROM students WHERE rollno = ?");
    $check->execute([$rollno]);

    if($check->rowCount() > 0) {
        $error = "Student already registered!";
    } else {
        // Insert student
        $stmt = $pdo->prepare("INSERT INTO students (name, rollno, phone, semester, department, password) VALUES (?, ?, ?, ?, ?, ?)");
        
        if($stmt->execute([$name, $rollno, $phone, $semester, $department, $password])) {
            $success = "Registration successful! Redirecting to login...";
            header("refresh:2;url=student_login.php");
        } else {
            $error = "Something went wrong!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Registration | Campus Portal</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        position: relative;
        overflow-x: hidden;
    }

    /* Animated Background Bubbles */
    body::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: 
            radial-gradient(circle at 20% 80%, rgba(255,255,255,0.1) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(255,255,255,0.08) 0%, transparent 50%);
        pointer-events: none;
    }

    @keyframes float {
        0%, 100% { transform: translateY(0) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(5deg); }
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }

    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }

    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }

    /* Register Container */
    .register-container {
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(10px);
        border-radius: 32px;
        padding: 40px 32px;
        width: 100%;
        max-width: 460px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        animation: fadeInUp 0.6s ease-out;
        position: relative;
        z-index: 1;
        transition: all 0.3s ease;
    }

    @media (max-width: 480px) {
        .register-container {
            padding: 30px 24px;
            border-radius: 28px;
        }
    }

    /* Register Header */
    .register-header {
        text-align: center;
        margin-bottom: 32px;
    }

    .register-header .logo-icon {
        font-size: 56px;
        margin-bottom: 16px;
        display: inline-block;
        animation: float 3s ease-in-out infinite;
    }

    .register-header h1 {
        font-size: 28px;
        font-weight: 800;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        background-clip: text;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 8px;
    }

    @media (max-width: 480px) {
        .register-header h1 {
            font-size: 24px;
        }
    }

    .register-header p {
        color: #6c757d;
        font-size: 14px;
    }

    /* Error & Success Messages */
    .error-message {
        background: linear-gradient(135deg, #f8d7da 0%, #fce4e6 100%);
        color: #c0392b;
        padding: 14px 18px;
        border-radius: 16px;
        margin-bottom: 24px;
        text-align: center;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        border-left: 4px solid #e74c3c;
        animation: shake 0.4s ease;
    }

    .success-message {
        background: linear-gradient(135deg, #d4edda 0%, #e8f5e9 100%);
        color: #27ae60;
        padding: 14px 18px;
        border-radius: 16px;
        margin-bottom: 24px;
        text-align: center;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        border-left: 4px solid #27ae60;
        animation: fadeInUp 0.4s ease;
    }

    .error-message i, .success-message i {
        font-size: 18px;
    }

    /* Form Styles */
    .register-form .form-group {
        margin-bottom: 24px;
    }

    .register-form label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #1a1a2e;
        font-size: 14px;
    }

    .register-form label i {
        margin-right: 8px;
        color: #667eea;
    }

    .input-wrapper {
        position: relative;
    }

    .register-form input,
    .register-form select {
        width: 100%;
        padding: 14px 16px 14px 48px;
        border: 2px solid #e9ecef;
        border-radius: 16px;
        font-size: 15px;
        font-family: inherit;
        transition: all 0.3s ease;
        background: #f8f9fa;
    }

    .register-form select {
        padding: 14px 16px 14px 48px;
        appearance: none;
        cursor: pointer;
    }

    .register-form input:focus,
    .register-form select:focus {
        outline: none;
        border-color: #667eea;
        background: white;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15);
    }

    .input-wrapper i {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #adb5bd;
        font-size: 18px;
        transition: color 0.3s ease;
        pointer-events: none;
    }

    .register-form input:focus + i,
    .register-form select:focus + i {
        color: #667eea;
    }

    /* Button Styles */
    .btn-register {
        width: 100%;
        padding: 14px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 40px;
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        margin-top: 8px;
        position: relative;
        overflow: hidden;
    }

    .btn-register::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        transition: left 0.5s ease;
    }

    .btn-register:hover::before {
        left: 100%;
    }

    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px -5px rgba(102, 126, 234, 0.4);
    }

    .btn-register:active {
        transform: translateY(0);
    }

    /* Demo Credentials */
    .demo-credentials {
        margin-top: 32px;
        padding: 20px;
        background: linear-gradient(135deg, #f8f9fa 0%, #f1f3f5 100%);
        border-radius: 20px;
        transition: all 0.3s ease;
    }

    .demo-credentials:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }

    .demo-credentials h4 {
        margin-bottom: 12px;
        color: #1a1a2e;
        font-size: 14px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .demo-credentials h4 i {
        color: #f39c12;
    }

    .demo-credentials p {
        margin: 6px 0;
        color: #6c757d;
        font-size: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .demo-credentials p i {
        width: 20px;
        color: #667eea;
    }

    .demo-credentials small {
        display: block;
        margin-top: 12px;
        font-size: 11px;
        color: #adb5bd;
        text-align: center;
    }

    /* Footer Links */
    .register-footer {
        text-align: center;
        margin-top: 24px;
        padding-top: 20px;
        border-top: 1px solid #e9ecef;
    }

    .register-footer a {
        color: #667eea;
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
        transition: color 0.3s ease;
    }

    .register-footer a:hover {
        color: #764ba2;
    }

    /* Warning Message */
    .warning-message {
        background: #fff3cd;
        color: #856404;
        padding: 10px;
        border-radius: 12px;
        margin-bottom: 16px;
        text-align: center;
        font-size: 13px;
        border-left: 3px solid #ffc107;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        body {
            padding: 16px;
        }
        
        .register-container {
            max-width: 100%;
        }
    }

    @media (max-width: 480px) {
        .register-container {
            padding: 28px 20px;
        }
        
        .register-header .logo-icon {
            font-size: 48px;
        }
        
        .register-form input,
        .register-form select {
            padding: 12px 16px 12px 44px;
            font-size: 14px;
        }
        
        .input-wrapper i {
            font-size: 16px;
            left: 14px;
        }
        
        .btn-register {
            padding: 12px;
            font-size: 15px;
        }
    }

    /* Dark mode support */
    @media (prefers-color-scheme: dark) {
        .register-container {
            background: rgba(30, 30, 40, 0.98);
        }
        
        .register-header p,
        .demo-credentials p,
        .demo-credentials small {
            color: #a0a0b0;
        }
        
        .demo-credentials {
            background: rgba(40, 40, 50, 0.8);
        }
        
        .demo-credentials h4 {
            color: white;
        }
        
        .register-form input,
        .register-form select {
            background: #2a2a35;
            border-color: #3a3a45;
            color: #003eff;
        }
        
        .register-form label {
            color: #e0e0e0;
        }
        
        .register-footer {
            border-top-color: #3a3a45;
        }
    }

    /* Loading state for button */
    .btn-register.loading {
        pointer-events: none;
        opacity: 0.7;
    }

    .btn-register.loading i {
        animation: pulse 1s ease infinite;
    }
</style>

</head>
<body>

<div class="register-container">
    <div class="register-header">
        <div class="logo-icon">
            🎓
        </div>
        <h1>Create Account</h1>
        <p>Join our learning community today</p>
    </div>

    <?php if($error): ?>
        <div class="error-message">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <?php if($success): ?>
        <div class="success-message">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <?php if(empty($departments)): ?>
        <div class="warning-message">
            <i class="fas fa-exclamation-triangle"></i>
            No departments found. Please contact administrator.
        </div>
    <?php endif; ?>

    <form method="POST" class="register-form">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Full Name</label>
            <div class="input-wrapper">
                <input type="text" name="name" placeholder="Enter your full name" required>
                <i class="fas fa-user"></i>
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-id-card"></i> Roll Number</label>
            <div class="input-wrapper">
                <input type="text" name="rollno" placeholder="Enter your roll number" required>
                <i class="fas fa-hashtag"></i>
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-phone"></i> Phone Number</label>
            <div class="input-wrapper">
                <input type="tel" name="phone" placeholder="Enter your phone number" required>
                <i class="fas fa-mobile-alt"></i>
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Semester</label>
            <div class="input-wrapper">
                <select name="semester" required>
                    <option value="">Select Semester</option>
                    <?php for($i=1; $i<=8; $i++): ?>
                        <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                    <?php endfor; ?>
                </select>
                <i class="fas fa-layer-group"></i>
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-building"></i> Department</label>
            <div class="input-wrapper">
                <select name="department" required <?php echo empty($departments) ? 'disabled' : ''; ?>>
                    <option value="">Select Department</option>
                    <?php foreach($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['name']); ?>">
                            <?php echo htmlspecialchars($dept['name']); ?> (<?php echo htmlspecialchars($dept['code']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <i class="fas fa-university"></i>
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-lock"></i> Password</label>
            <div class="input-wrapper">
                <input type="password" name="password" placeholder="Create a password" required>
                <i class="fas fa-key"></i>
            </div>
        </div>

        <button type="submit" class="btn-register">
            <i class="fas fa-user-plus"></i>
            Register Now
        </button>
    </form>

    <div class="register-footer">
        <a href="student_login.php">
            <i class="fas fa-sign-in-alt"></i> Already have an account? Login here
        </a>
    </div>
</div>

<script>
// Add loading state to button on form submit
document.querySelector('form').addEventListener('submit', function() {
    const btn = document.querySelector('.btn-register');
    btn.classList.add('loading');
    btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Registering...';
});
</script>

</body>
</html>