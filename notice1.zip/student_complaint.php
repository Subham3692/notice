<?php
session_start();
require_once 'admin/database.php';

if(!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: student_login.php');
    exit();
}

$student_name = $_SESSION['student_name'];
$student_rollno = $_SESSION['student_rollno'];
$student_phone = $_SESSION['student_phone'];
$student_department = $_SESSION['student_department'];
$student_semester = $_SESSION['student_semester'];
$student_email = $_SESSION['student_email'] ?? '';

$message = '';
$error = '';

// Handle complaint submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_complaint'])) {
    $complaint_subject = trim($_POST['complaint_subject']);
    $complaint_message = trim($_POST['complaint_message']);
    $student_email_input = trim($_POST['student_email'] ?? '');
    $complaint_date = date('Y-m-d');
    
    if(empty($complaint_subject)) {
        $error = "Please enter a complaint subject.";
    } elseif(empty($complaint_message)) {
        $error = "Please enter your complaint details.";
    } elseif(strlen($complaint_message) < 10) {
        $error = "Please provide more details (minimum 10 characters).";
    } else {
        $stmt = $pdo->prepare("INSERT INTO student_complaints 
            (student_name, student_rollno, student_phone, student_email, department, semester, complaint_subject, complaint_message, complaint_date, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        
        if($stmt->execute([
            $student_name, 
            $student_rollno, 
            $student_phone, 
            $student_email_input ?: $student_email, 
            $student_department, 
            $student_semester, 
            $complaint_subject, 
            $complaint_message, 
            $complaint_date
        ])) {
            $message = "✅ Your complaint has been submitted successfully! You can track its status below.";
            $_POST = array();
        } else {
            $error = "❌ Failed to submit complaint. Please try again.";
        }
    }
}

// Fetch user's complaints
$stmt = $pdo->prepare("SELECT * FROM student_complaints WHERE student_rollno = ? ORDER BY created_at DESC, id DESC");
$stmt->execute([$student_rollno]);
$complaints = $stmt->fetchAll();

$status_config = [
    'pending' => ['color' => '#f39c12', 'bg' => '#fff3cd', 'icon' => '⏳', 'label' => 'Pending'],
    'in_progress' => ['color' => '#3498db', 'bg' => '#d1ecf1', 'icon' => '🔄', 'label' => 'In Progress'],
    'resolved' => ['color' => '#2ecc71', 'bg' => '#d4edda', 'icon' => '✅', 'label' => 'Resolved'],
    'rejected' => ['color' => '#e74c3c', 'bg' => '#f8d7da', 'icon' => '❌', 'label' => 'Rejected']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Student Complaints - Student Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
        <style>
        .logo a {
    text-decoration: none;
    color: inherit;
}
        </style>
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="logo-area">
            <a href="index.php" style="text-decoration: none; color: inherit;">
            <h2>🎓 Online Notice</h2>
            </a>
        </div>
        <div class="student-info">
            <div class="student-details">
                <div class="student-name"><?php echo htmlspecialchars($student_name); ?></div>
                <div class="student-roll"><?php echo htmlspecialchars($student_rollno); ?></div>
            </div>
            <a href="index.php" class="back-btn">Back</a>
        </div>
    </div>
    
    <!-- Page Header -->
    <div class="page-header">
                <br>
        <h1><i class="fas fa-file-alt"></i> Student Complaint System</h1>
        <p>Submit your complaints/grievances and track their resolution status</p>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <?php if($message): ?>
                <div class="success-message"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="error-message"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
                        
            <!-- Submit Complaint Form -->
            <div class="form-card">
                <h2><i class="fas fa-pen-alt"></i> Submit New Complaint</h2>
                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Your Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($student_name); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Roll Number</label>
                            <input type="text" value="<?php echo htmlspecialchars($student_rollno); ?>" disabled>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Department</label>
                            <input type="text" value="<?php echo htmlspecialchars($student_department); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Semester</label>
                            <input type="text" value="Semester <?php echo $student_semester; ?>" disabled>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" value="<?php echo htmlspecialchars($student_phone); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Email (Optional)</label>
                            <input type="email" name="student_email" placeholder="your@email.com" value="<?php echo htmlspecialchars($student_email); ?>">
                            <small>For receiving updates via email</small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Complaint Subject <span class="required">*</span></label>
                        <input type="text" name="complaint_subject" required placeholder="Brief subject of your complaint" value="<?php echo htmlspecialchars($_POST['complaint_subject'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Complaint Details <span class="required">*</span></label>
                        <textarea name="complaint_message" required rows="5" placeholder="Please describe your complaint in detail... (Include relevant dates, names, and evidence if possible)"><?php echo htmlspecialchars($_POST['complaint_message'] ?? ''); ?></textarea>
                        <small>Minimum 10 characters. Be specific and provide all relevant information.</small>
                    </div>
                    
                    <button type="submit" name="submit_complaint" class="btn-submit">
                        <i class="fas fa-paper-plane"></i> Submit Complaint
                    </button>
                </form>
            </div>
            
            <!-- My Complaints List -->
            <div class="complaints-card">
                <h2><i class="fas fa-list"></i> My Complaints 
                    <?php if(!empty($complaints)): ?>
                        <span class="badge-count"><?php echo count($complaints); ?></span>
                    <?php endif; ?>
                </h2>
                
                <?php if(empty($complaints)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No Complaints Submitted Yet</h3>
                        <p>Use the form above to submit your first complaint.</p>
                    </div>
                <?php else: ?>
                    <?php foreach($complaints as $complaint): ?>
                        <?php 
                        $status = $complaint['status'];
                        $config = $status_config[$status] ?? $status_config['pending'];
                        ?>
                        <div class="complaint-item">
                            <div class="complaint-header">
                                <div class="complaint-subject"><?php echo htmlspecialchars($complaint['complaint_subject']); ?></div>
                                <span class="complaint-status" style="background: <?php echo $config['bg']; ?>; color: <?php echo $config['color']; ?>;">
                                    <?php echo $config['icon']; ?> <?php echo $config['label']; ?>
                                </span>
                            </div>
                            
                            <div class="complaint-meta">
                                <span><i class="far fa-calendar-alt"></i> Submitted: <?php echo date('d F Y', strtotime($complaint['complaint_date'])); ?></span>
                                <span><i class="fas fa-hashtag"></i> Complaint ID: #<?php echo $complaint['id']; ?></span>
                                <?php if($complaint['resolved_date']): ?>
                                    <span><i class="fas fa-check-circle"></i> Resolved: <?php echo date('d F Y', strtotime($complaint['resolved_date'])); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="complaint-message"><?php echo nl2br(htmlspecialchars($complaint['complaint_message'])); ?></div>
                            
                            <?php if($complaint['admin_response']): ?>
                                <div class="admin-response">
                                    <strong><i class="fas fa-reply"></i> Admin Response:</strong>
                                    <?php echo nl2br(htmlspecialchars($complaint['admin_response'])); ?>
                                </div>
                            <?php elseif($status == 'pending'): ?>
                                <div style="margin-top: 10px; font-size: 12px; color: #f39c12;">
                                    <i class="fas fa-clock"></i> Awaiting admin response...
                                </div>
                            <?php elseif($status == 'in_progress'): ?>
                                <div style="margin-top: 10px; font-size: 12px; color: #3498db;">
                                    <i class="fas fa-spinner fa-pulse"></i> Your complaint is being reviewed...
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Bottom Navigation (Mobile) -->
    <div class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="class_notices.php" class="nav-item">
            <i class="fas fa-book"></i>
            <span>Class</span>
        </a>
        <a href="college_notices.php" class="nav-item">
            <i class="fas fa-university"></i>
            <span>College</span>
        </a>
        <a href="events.php" class="nav-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Events</span>
        </a>
        <a href="teacher_notices.php" class="nav-item active">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teacher</span>
        </a>
    </div>
</body>
</html>

