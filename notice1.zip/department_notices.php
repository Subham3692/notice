<?php
session_start();
require_once 'admin/database.php';

if(!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: student_login.php');
    exit();
}

$student_name = $_SESSION['student_name'];
$student_rollno = $_SESSION['student_rollno'];
$student_department = $_SESSION['student_department'];
$student_semester = $_SESSION['student_semester'];

$stmt = $pdo->prepare("SELECT * FROM department_notices WHERE department = ? ORDER BY notice_date DESC, id DESC");
$stmt->execute([$student_department]);
$notices = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Department Notices - Student Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
        <script src="script.js"></script>
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.95);
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

/* Image */
.modal-content {
    max-width: 95%;
    max-height: 90%;
    width: auto;
    height: auto;
    object-fit: contain;

    cursor: grab;
    transition: transform 0.1s ease;
    user-select: none;
}


/* Close */
.close {
    position: absolute;
    top: 20px;
    right: 30px;
    font-size: 35px;
    color: #fff;
    cursor: pointer;
}
.logo a {
    text-decoration: none;
    color: inherit;
}
</style>

</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="logo-area">
            <a href="index.php" style="text-decoration: none; color: inherit;">
            <h2>🎓 Online Notice</h2>
            </a>
        </div>
        <div class="student-info">
            <div class="student-details">
                <div class="student-name"><?php echo htmlspecialchars($student_name); ?></div>
                <div class="student-roll"><?php echo htmlspecialchars($student_rollno); ?></div>
            </div>
            <a href="index.php" class="back-btn">Back</a>
        </div>
    </div>
    
    <!-- Page Header -->
    <div class="page-header">
                <br>
        <h1>🏛️ Department Notices</h1>
        <p>Department of <?php echo htmlspecialchars($student_department); ?></p>
        <div class="info-badge">
            <i class="fas fa-users"></i> Updates from your department
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <?php if(empty($notices)): ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <h3>No Department Notices Found</h3>
                    <p>No notices have been posted for your department yet.</p>
                </div>
            <?php else: ?>
                <?php foreach($notices as $notice): ?>
                    <div class="notice-card">
                        <div class="notice-title"><?php echo htmlspecialchars($notice['title']); ?></div>
                        <div class="notice-meta">
                            <span><i class="far fa-calendar-alt"></i> <?php echo date('d F Y', strtotime($notice['notice_date'])); ?></span>
                            <span><i class="fas fa-building"></i> <?php echo htmlspecialchars($notice['department']); ?></span>
                        </div>
                        <div class="notice-text"><?php echo nl2br(htmlspecialchars($notice['notice_text'])); ?></div>
                        <?php if($notice['link_url']): ?>
                            <div class="event-link">
                                <a href="<?php echo htmlspecialchars($notice['link_url']); ?>" target="_blank">
                                    <i class="fas fa-external-link-alt"></i> Notice Link →
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php if($notice['image_path'] && file_exists('admin/' . $notice['image_path'])): ?>
                            <div class="notice-image">
                                <img src="admin/<?php echo $notice['image_path']; ?>" alt="Notice Image" onclick="openModal(this.src)">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Bottom Navigation (Mobile) -->
    <div class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="class_notices.php" class="nav-item">
            <i class="fas fa-book"></i>
            <span>Class</span>
        </a>
        <a href="college_notices.php" class="nav-item">
            <i class="fas fa-university"></i>
            <span>College</span>
        </a>
        <a href="events.php" class="nav-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Events</span>
        </a>
        <a href="student_complaint.php" class="nav-item">
            <i class="fas fa-file-alt"></i>
            <span>Complaint</span>
        </a>
    </div>

    <!-- Image Modal -->
<div id="imageModal" class="modal" onclick="closeModal()">
    <span class="close">&times;</span>
    <img id="modalImg" class="modal-content">
</div>

</body>
</html>