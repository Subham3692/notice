<?php
session_start();
require_once 'admin/database.php';

if(!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: student_login.php');
    exit();
}

$student_name = $_SESSION['student_name'];
$student_rollno = $_SESSION['student_rollno'];
$student_department = $_SESSION['student_department'];
$student_semester = $_SESSION['student_semester'];

// First try to get semester-specific teacher notices
$stmt = $pdo->prepare("SELECT tn.*, t.name as teacher_name 
                       FROM teacher_notices tn 
                       LEFT JOIN teachers t ON tn.teacher_id = t.id 
                       WHERE tn.department = ? AND tn.semester = ? 
                       ORDER BY tn.notice_date DESC, tn.id DESC");
$stmt->execute([$student_department, $student_semester]);
$notices = $stmt->fetchAll();

// If no semester-specific notices, show all department notices
$showFallback = false;
if(empty($notices)) {
    $stmt = $pdo->prepare("SELECT tn.*, t.name as teacher_name 
                           FROM teacher_notices tn 
                           LEFT JOIN teachers t ON tn.teacher_id = t.id 
                           WHERE tn.department = ? 
                           ORDER BY tn.notice_date DESC, tn.id DESC");
    $stmt->execute([$student_department]);
    $notices = $stmt->fetchAll();
    $showFallback = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Teacher Notices - Student Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
    <style>
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.95);
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

/* Image */
.modal-content {
    max-width: 95%;
    max-height: 90%;
    width: auto;
    height: auto;
    object-fit: contain;

    cursor: grab;
    transition: transform 0.1s ease;
    user-select: none;
}


/* Close */
.close {
    position: absolute;
    top: 20px;
    right: 30px;
    font-size: 35px;
    color: #fff;
    cursor: pointer;
}

        .logo a {
    text-decoration: none;
    color: inherit;
}

</style>

</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="logo-area">
            <a href="index.php" style="text-decoration: none; color: inherit;">
            <h2>🎓 Online Notice</h2>
            </a>
        </div>
        <div class="student-info">
            <div class="student-details">
                <div class="student-name"><?php echo htmlspecialchars($student_name); ?></div>
                <div class="student-roll"><?php echo htmlspecialchars($student_rollno); ?></div>
            </div>
            <a href="index.php" class="back-btn">Back</a>
        </div>
    </div>
    
    <!-- Page Header -->
    <div class="page-header">
                <br>
        <h1>👩‍🏫 Teacher Notices</h1>
        <p>Semester <?php echo $student_semester; ?> | Department of <?php echo htmlspecialchars($student_department); ?></p>
        <div class="info-badge">
            <i class="fas fa-chalkboard-user"></i> Updates from your teachers
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <?php if($showFallback && !empty($notices)): ?>
            <?php endif; ?>
            
            <?php if(empty($notices)): ?>
                <div class="empty-state">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <h3>No Teacher Notices Found</h3>
                    <p>No teacher notices have been posted for your class yet.</p>
                    <p style="margin-top: 10px; font-size: 13px; color: #888;">
                        Department: <?php echo htmlspecialchars($student_department); ?> | Semester: <?php echo $student_semester; ?>
                    </p>
                </div>
            <?php else: ?>
                <?php foreach($notices as $notice): ?>
                    <div class="notice-card">
                        <div class="notice-title">
                            <?php echo htmlspecialchars($notice['title']); ?>
                            <?php if($notice['semester'] != $student_semester): ?>
                                <span class="notice-semester">Semester <?php echo $notice['semester']; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="teacher-name">
                            <i class="fas fa-user-tie"></i> By: <?php echo htmlspecialchars($notice['teacher_name'] ?? 'Unknown Teacher'); ?>
                        </div>
                        <div class="notice-meta">
                            <span><i class="far fa-calendar-alt"></i> <?php echo date('d F Y', strtotime($notice['notice_date'])); ?></span>
                            <span><i class="fas fa-building"></i> <?php echo htmlspecialchars($notice['department']); ?></span>
                            <?php if($notice['semester']): ?>
                                <span><i class="fas fa-graduation-cap"></i> Semester <?php echo $notice['semester']; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="notice-text"><?php echo nl2br(htmlspecialchars($notice['notice_text'])); ?></div>
                        <?php if($notice['link_url']): ?>
                            <div class="event-link">
                                <a href="<?php echo htmlspecialchars($notice['link_url']); ?>" target="_blank">
                                    <i class="fas fa-external-link-alt"></i> Notice Link →
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php if($notice['image_path'] && file_exists('admin/' . $notice['image_path'])): ?>
                            <div class="notice-image">
                                <img src="admin/<?php echo $notice['image_path']; ?>" alt="Notice Image" onclick="openModal(this.src)">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Bottom Navigation (Mobile) -->
    <div class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="class_notices.php" class="nav-item">
            <i class="fas fa-book"></i>
            <span>Class</span>
        </a>
        <a href="college_notices.php" class="nav-item">
            <i class="fas fa-university"></i>
            <span>College</span>
        </a>
        <a href="events.php" class="nav-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Events</span>
        </a>
        <a href="student_complaint.php" class="nav-item">
            <i class="fas fa-file-alt"></i>
            <span>Complaint</span>
        </a>
    </div>

    <!-- Image Modal -->
<div id="imageModal" class="modal" onclick="closeModal()">
    <span class="close">&times;</span>
    <img id="modalImg" class="modal-content">
</div>

</body>
</html>
